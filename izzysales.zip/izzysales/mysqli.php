<?php

/* 
DB Connection file 
 */
include('config.php');
  $mysqli = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
    if ($mysqli->connect_error){
        die('Could not connect to database!');
    }
