$(document).ready(function() {
    
	$("#submit-login").click(function(event){
        $.post("includes/validate.php", $('#loginfrm').serialize(), function(data){
		$("#user-result").html(data);
		     });

		  });	 

   var input = document.getElementById("username");
	input.addEventListener("keypress", function(event) {
	if (event.key === "") {
    event.preventDefault();
    document.getElementById("submit-login").click();
				}
			});
		  
	var input = document.getElementById("password");
	input.addEventListener("keypress", function(event) {
	if (event.key === "") {
    event.preventDefault();
    document.getElementById("submit-login").click();
				}
			});


	var input = document.getElementById("username");
	input.addEventListener("keypress", function(event) {
	if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("submit-login").click();
				}
			});
		  
	
	var input = document.getElementById("password");
	input.addEventListener("keypress", function(event) {
	if (event.key === "Enter") {
    event.preventDefault();
    document.getElementById("submit-login").click();
				}
			});

	
		  
	  var input = document.getElementById("newuser");
	input.addEventListener("change", function(event){
          $.post("includes/check_subscriber.php", $('#loginsubscribe').serialize(), function(data){
		$("#user-result3").html(data);
		     });

		  });
		  
		 var input = document.getElementById("newphone");
	input.addEventListener("change", function(event){
        $.post("includes/check_subscriber_phone.php", $('#loginsubscribe').serialize(), function(data){
		$("#user-result4").html(data);
		     });

		  });  
		  
		$("#submit-subscriber").click(function(event){
        $.post("includes/validate_subscriber.php", $('#loginsubscribe').serialize(), function(data){
		$("#user-result3").html(data);
		     });

		  });
			   
			   
			   
});
