
        <!--**********************************
            Footer start
        ***********************************-->
        <div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        


    </div>
    <script src="../../vendor/global/global.min.js"></script>
    <script src="../../js/custom.min.js"></script>
    
    
    

</body>

</html>