<ul class="nav navbar-nav navbar-right ml-auto">
			
			<li class="nav-item dropdown" style="text-align: right">
				
				<a href="https://billionengineers.co.in/webapp/"><img src="https://billionengineers.co.in/webapp/img/login-but.png" class="avatar" alt="Avatar" style="width: 25px; height: 25px;"> PRODUCTS </a>
				
			</li>
		</ul>

