<?php //session_start();
 if (!isset($_SESSION["user_name"])) {
	 header("location:login.php");
	 die;
 } 
 if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] == "admin") {
	 global $logged_user_name;
	 global $logged_user_id;
	 global $logged_user_fname;
	 global $logged_user_lname;
	 global $logged_user_img;
	 global $logged_user_role;
	 $logged_user_role = $_SESSION["user_role"];
	 $logged_user_name = $_SESSION["user_name"];
	 $logged_user_id = $_SESSION["user_id"];
	 $logged_user_fname = $_SESSION["user_fname"];
	 $logged_user_lname = $_SESSION["user_lname"];
	 $logged_user_img = $_SESSION["user_img"];
	 
 } else {
	 header("location:login.php");
	 die;
 }
 
define('useraccess', TRUE);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>izzysales Dashboard </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="../images/favicon.png">
    <link href="../css/style.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


</head>