<?php
include('../../mysqli.php');
$goods_id = $mysqli -> real_escape_string($_POST['goods_id']);
$var_id = $_POST['var_id'];

include('../func/redirect.inc.php');

if(empty($goods_id)) {
	echo '<script>'.'alert("Please enter valid details")'.'</script>';
	redirect_user("../admin/add_products.php");
	die();
}


$brand_var = $mysqli -> real_escape_string($_POST['brand_var']);
$hsn_var = $mysqli -> real_escape_string($_POST['hsn_var']);
$color_var = $mysqli -> real_escape_string($_POST['color_var']);
$size_var = $mysqli -> real_escape_string($_POST['size_var']);
$weight_var = $mysqli -> real_escape_string($_POST['weight_var']);
$vol_var = $mysqli -> real_escape_string($_POST['vol_var']);
$length_var = $mysqli -> real_escape_string($_POST['length_var']);
$breadth_var = $mysqli -> real_escape_string($_POST['breadth_var']);
$height_var = $mysqli -> real_escape_string($_POST['height_var']);
$model_var = $mysqli -> real_escape_string($_POST['model_var']);
$price_var = $mysqli -> real_escape_string($_POST['price_var']);
$discount_price_var = $mysqli -> real_escape_string($_POST['discount_price_var']);
$stock_var = $mysqli -> real_escape_string($_POST['stock_var']);
$sku_var = $mysqli -> real_escape_string($_POST['sku_var']);



$sql="UPDATE izzysales_products_details SET color='$color_var', hsn_code='$hsn_var', length = '$length_var', breadth = '$breadth_var', height='$height_var', size='$size_var', weight = '$weight_var', volume = '$vol_var', brand='$brand_var', model='$model_var', price = '$price_var', discount_price = '$discount_price_var', stock = '$stock_var', min_sku = '$sku_var' WHERE goods_id = '$goods_id' && variant_num = '$var_id'";


if (mysqli_query($mysqli,$sql)){
echo '<script>';
echo 'alert("Changes saved")'; 
echo '</script>';
$url="../admin/add_products.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
} else {
	echo "Error in saving changes";
}




?>