<?php

$order_id = $_POST['order_name'];
$customer_id = '110110';//$_POST["customer_name"];
$total_entries = $_POST["total_serial"];
$loop_num = $total_entries;
include('../func/redirect.inc.php');

if(empty($order_id)) {
	echo '<script>'.'alert("Please enter valid details")'.'</script>';
	redirect_user("../admin/new_sale.php");
	die();
}



for($num = 1; $num <= $loop_num; $num++){
${'product_id'.$num} = ${'_POST'}['prod_name'.$num];
${'old_product_id'.$num} = ${'_POST'}['old_prod_id'.$num];
${'old_id'.$num} = ${'_POST'}['old_id'.$num];
${'variant'.$num} = ${'_POST'}['variant'.$num];
${'old_variant'.$num} = ${'_POST'}['old_variant'.$num];
${'unit'.$num} = ${'_POST'}['unit'.$num];
${'quantity'.$num} = ${'_POST'}['quantity'.$num];
${'bill_amount'.$num} = ${'_POST'}['bill_amount'.$num];
}

//Validation
for($num = 1; $num <= $loop_num; $num++){
if (${'product_id'.$num} =="" || ${'variant'.$num} =="" || ${'unit'.$num} =="" || ${'quantity'.$num} =="" || ${'bill_amount'.$num} =="") {
	echo 'Error: Please select fields correctly';
	die;
}
}
include('../../mysqli.php');



//GET NEW STOCK

for($num = 1; $num <= $loop_num; $num++){
${'sqlquery'.$num} = "SELECT * FROM `izzysales_products_details` WHERE variant_num = '${'variant'.$num}' && goods_id = '${'product_id'.$num}'";

		${'result'.$num} = mysqli_query ($mysqli, ${'sqlquery'.$num});
		if (mysqli_num_rows(${'result'.$num}) > 0) {
				while(${'row'.$num} = ${'result'.$num}->fetch_assoc()) {
						${'up_prod_stock'.$num} = ${'row'.$num}["stock"];
						}
		} else {
			echo "Error: The variant for selected product doesn't exist";
			die();
		} 
		
${'upnew_prod_stock'.$num} = ${'up_prod_stock'.$num} - ${'quantity'.$num};		
${'sqlr'.$num} = "UPDATE izzysales_products_details SET stock = '${'upnew_prod_stock'.$num}' WHERE goods_id = '${'product_id'.$num}' && variant_num = '${'variant'.$num}'";

$mysqli->query(${'sqlr'.$num});
//echo ${'sqlr'.$num}.'<br>';			
					
}

//GET STOCK OF ORIGINAL PRODS
for($num = 1; $num <= $loop_num; $num++){
	
	
${'sqlquery'.$num} = "SELECT * FROM `izzysales_products_details` WHERE variant_num = '${'old_variant'.$num}' && goods_id = '${'old_product_id'.$num}'";
		${'result'.$num} = mysqli_query ($mysqli, ${'sqlquery'.$num});
		if (mysqli_num_rows(${'result'.$num}) > 0) {
				while(${'row'.$num} = ${'result'.$num}->fetch_assoc()) {
						${'old_prod_stock'.$num} = ${'row'.$num}["stock"];
					   	}
		} else {
			echo "Error: This variant for selected product doesn't exist";
			die();
		}

		
	${'sqlquery'.$num} = "SELECT * FROM `izzysales_orders` WHERE id = '${'old_id'.$num}'";
		${'result'.$num} = mysqli_query ($mysqli, ${'sqlquery'.$num});
		if (mysqli_num_rows(${'result'.$num}) > 0) {
				while(${'row'.$num} = ${'result'.$num}->fetch_assoc()) {
						${'old_quantity'.$num} = ${'row'.$num}["quantity"];
					   	}	
		} else {
			echo "Error";
			die();
		}
		
			
	${'restored_prod_stock'.$num} = ${'old_prod_stock'.$num} + ${'old_quantity'.$num};	

	${'sqlr'.$num} = "UPDATE izzysales_products_details SET stock = '${'restored_prod_stock'.$num}' WHERE goods_id = '${'old_product_id'.$num}' && variant_num = '${'old_variant'.$num}'";
$mysqli->query(${'sqlr'.$num});						
}





for ($sqnum = 1; $sqnum <= $loop_num; $sqnum++) {
${'sqlquery'.$sqnum} = "SELECT * FROM `izzysales_products` WHERE goods_id = '${'product_id'.$sqnum}'";
		${'result'.$sqnum} = mysqli_query ($mysqli, ${'sqlquery'.$sqnum});
		if (mysqli_num_rows(${'result'.$sqnum}) > 0) {
				while(${'row'.$sqnum} = ${'result'.$sqnum}->fetch_assoc()) {
						${'prod_name'.$sqnum} = ${'row'.$sqnum}["goods_name"];
					   
						}
        } else {
			echo "Error";
			die();
		} 
}


for ($sqlnumr = 1; $sqlnumr <= $loop_num; $sqlnumr++){
	${'prod_price'.$sqlnumr} = ${'quantity'.$sqlnumr}*${'bill_amount'.$sqlnumr};
	${'sqlr'.$sqlnumr} = "UPDATE izzysales_orders SET product_id = '${'product_id'.$sqlnumr}', product_name ='${'prod_name'.$sqlnumr}', variant = '${'variant'.$sqlnumr}', unit ='${'unit'.$sqlnumr}', quantity = '${'quantity'.$sqlnumr}', bill_amount = '${'prod_price'.$sqlnumr}' WHERE id ='${'old_id'.$sqlnumr}'";
	
}

for ($qrnumb = 1; $qrnumb <= $loop_num; $qrnumb++){
$mysqli->query(${'sqlr'.$qrnumb});
} 

$url="../admin/new_sale.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	


?>