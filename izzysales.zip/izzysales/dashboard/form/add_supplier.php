<?php

include('../../mysqli.php');
$supplier_name = $mysqli -> real_escape_string($_POST['supplier_name']);
$person_name = $mysqli -> real_escape_string($_POST['person_name']);
$contact_num = $mysqli -> real_escape_string($_POST['contact_num']);
$address = $mysqli -> real_escape_string($_POST['address']);
$gst = $mysqli -> real_escape_string($_POST['gst']);
$credit = $mysqli -> real_escape_string($_POST['credit']);
$debit = $mysqli -> real_escape_string($_POST['debit']);


include('../func/redirect.inc.php');

if(empty($supplier_name)) {
	echo '<script>'.'alert("Please select valid Supplier Name")'.'</script>';
	redirect_user("../admin/add_supplier.php");
	die();
}


if($credit ==""){
	$credit = 0;
}
if($debit ==""){
	$debit = 0;
}


$sql1 = "SELECT supplier_id FROM izzysales_suppliers ORDER BY supplier_id DESC LIMIT 1";
$result = mysqli_query($mysqli, $sql1);
while($row = $result->fetch_assoc()) {
	$last_supplier_id = $row['supplier_id'];
}
$new_supplier_id = $last_supplier_id + 1;


$sql2 = "INSERT INTO izzysales_suppliers(`supplier_id`, `supplier_name`, `supplier_phone`,`supplier_address`, `supplier_contact`, `supplier_gst`, `supplier_credit`, `supplier_debit`) VALUES('".$new_supplier_id."', '".$supplier_name."', '".$contact_num."', '".$address."', '".$person_name."', '".$gst."', '".$credit."', '".$debit."')";



if (mysqli_query($mysqli, $sql2)) {
echo '<script>'.'alert("Supplier added successfully")'.'</script>';
redirect_user("../admin/add_supplier.php");
die();
  
}
















?>