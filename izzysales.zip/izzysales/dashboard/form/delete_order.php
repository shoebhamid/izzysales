<?php

$order_id = $_POST['order_name'];
$customer_id = '110110';//$_POST["customer_name"];
$total_entries = $_POST["total_serial"];
$loop_num = $total_entries;

include('../func/redirect.inc.php');

if(empty($order_id)) {
	echo '<script>'.'alert("Please select an order")'.'</script>';
	redirect_user("../admin/new_order.php");
	die();
}



include('../../mysqli.php');
$sql="DELETE FROM izzysales_orders WHERE order_id = '$order_id'";
if (mysqli_query($mysqli,$sql)){
	echo '<script>';
echo 'alert("Order deleted")'; 
echo '</script>';
$url="../admin/new_order.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';
} else {
	echo "Error deleting the order";
}




?>