<?php
include('../../mysqli.php');
$customer_id = filter_var($_POST["customer_id"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);

if ( empty ($_POST["customer_name"])){
	$_POST["customer_name"] = "";
}
if ( empty ($_POST["customer_phone"])){
	$_POST["customer_phone"] = "";
} 
if ( empty ($_POST["customer_email"])){
	$_POST["customer_email"] = "";
}
if ( empty ($_POST["customer_address"])){
	$_POST["customer_address"] = "";
} 
  
$customer_name = filter_var($_POST["customer_name"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
$customer_phone= filter_var($_POST["customer_phone"], FILTER_VALIDATE_INT, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
$customer_email = filter_var($_POST["customer_email"], FILTER_SANITIZE_EMAIL, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
$customer_address = filter_var($_POST["customer_address"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);

$sql="UPDATE izzysales_customers SET customer_name='$customer_name', customer_phone='$customer_phone', customer_email = '$customer_email', customer_address = '$customer_address' WHERE customer_id = '$customer_id'";


if (mysqli_query($mysqli,$sql)){
echo '<script>';
echo 'alert("Changes saved")'; 
echo '</script>';
$url="../admin/register_customer.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
} else {
	echo "Error in saving changes";
}




?>