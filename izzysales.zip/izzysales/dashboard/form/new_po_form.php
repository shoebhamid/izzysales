<?php
include('../../mysqli.php');
$supplier_id = $mysqli -> real_escape_string($_POST['supplier_po_id']);

$purchase_id = $mysqli -> real_escape_string($_POST['new_po_id']);
$supplier_id = $mysqli -> real_escape_string($_POST['supplier_po_id']);
$product_id = $mysqli -> real_escape_string($_POST['prod_po_id']);
$product_name = $mysqli -> real_escape_string($_POST['prod_po_name']);
$variant = $mysqli -> real_escape_string($_POST['po_variant']);
$quantity = $mysqli -> real_escape_string($_POST['po_quantity']);
$unit = $mysqli -> real_escape_string($_POST['po_unit']);
$rate = $mysqli -> real_escape_string($_POST['po_rate']);
$paid_amount = $mysqli -> real_escape_string($_POST['po_paid_amount']);
$total_amount = $rate*$quantity;

include('../func/redirect.inc.php');

if(empty($purchase_id)) {
	echo '<script>'.'alert("Please enter valid details")'.'</script>';
	redirect_user("../admin/new_po.php");
	die();
}


$sql = "INSERT INTO izzysales_purchase_orders(`purchase_id`, `supplier_id`, `product_id`, `variant`, `product_name`, `rate`, `unit`, `quantity`, `total_amount`, `paid_amount`) VALUES('".$purchase_id."', '".$supplier_id."', '".$product_id."', '".$variant."', '".$product_name."', '".$rate."', '".$unit."', '".$quantity."', '".$total_amount."', '".$paid_amount."')";



if (mysqli_query($mysqli, $sql)) {
echo '<script>';
echo 'alert("PO added successfully")'; 
echo '</script>';
$url="../admin/new_po.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
  
}


?>