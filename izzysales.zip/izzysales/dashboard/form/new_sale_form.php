<?php session_start();

include('../../mysqli.php');
if(!isset($_POST["customer_name"])) {
	
$sqr="SELECT customer_id FROM izzysales_customers ORDER BY customer_id DESC LIMIT 1";
 $resu = mysqli_query($mysqli, $sqr);	
	while($rowe = $resu->fetch_assoc()){
		$last_cus_id = $rowe['customer_id'];
		$customer_id = $rowe['customer_id'] + 1;
		$customer_name = "";
	}
$sql_cust = "INSERT INTO izzysales_customers(`customer_id`, `customer_name`) VALUES ('".$customer_id."', '".$customer_name."')";
$mysqli->query($sql_cust); 	
	
	
} else {
	$customer_id = $_POST["customer_name"];
	$sqr="SELECT customer_name FROM izzysales_customers WHERE customer_id = '$customer_id'";
 $resu = mysqli_query($mysqli, $sqr);	
	while($rowe = $resu->fetch_assoc()){
		$customer_name = $rowe['customer_name'];
		
		}
	
	
	
}


$order_id = $_POST["order_id"];
$total_entries = $_POST["totalentries"];
$loop_num = $total_entries;



for($num = 1; $num <= $loop_num; $num++){
${'product_id'.$num} = ${'_POST'}['product_name'.$num];
${'variant'.$num} = ${'_POST'}['variant'.$num];
${'unit'.$num} = ${'_POST'}['unit'.$num];
${'quantity'.$num} = ${'_POST'}['quantity'.$num];
	
if (${'product_id'.$num} =="" OR ${'product_id'.$num} == 0){
	echo "Select Product";
	die();
}
if (${'variant'.$num} =="" OR ${'variant'.$num} == 0){
	echo "Select Variant";
	die();
}
/* if (${'unit'.$num} =="" OR ${'unit'.$num} == 0){
	echo "Select Unit";
	die();
} */
if (${'quantity'.$num} =="" OR ${'quantity'.$num} == 0){
	echo "Select Quantity";
	die();
}
}


for ($sqnum = 1; $sqnum <= $loop_num; $sqnum++) {
${'sqlquery'.$sqnum} = "SELECT * FROM `izzysales_products` WHERE goods_id = '${'product_id'.$sqnum}'";
		${'result'.$sqnum} = mysqli_query ($mysqli, ${'sqlquery'.$sqnum});
				while(${'row'.$sqnum} = ${'result'.$sqnum}->fetch_assoc()) {
						${'prod_name'.$sqnum} = ${'row'.$sqnum}["goods_name"];
					   
						}

}


for ($sqanum = 1; $sqanum <= $loop_num; $sqanum++) {
${'sqlqueryp'.$sqanum} = "SELECT * FROM `izzysales_products_details` WHERE goods_id = '${'product_id'.$sqanum}' && variant_num = '${'variant'.$sqanum}'";
		${'resultp'.$sqanum} = mysqli_query ($mysqli, ${'sqlqueryp'.$sqanum});
				while(${'row'.$sqanum} = ${'resultp'.$sqanum}->fetch_assoc()) {
						${'prod_stock'.$sqanum} = ${'row'.$sqanum}["stock"];
					    ${'new_prod_stock'.$sqanum} = ${'prod_stock'.$sqanum} - ${'quantity'.$sqanum};
						 ${'prod_price'.$sqanum} = ${'row'.$sqanum}["price"];
						}
}

for ($sqlnumr = 1; $sqlnumr <= $loop_num; $sqlnumr++){
	${'sqlr'.$sqlnumr} = "UPDATE izzysales_products_details SET stock = '${'new_prod_stock'.$sqlnumr}' WHERE goods_id = '${'product_id'.$sqlnumr}' && variant_num = '${'variant'.$sqlnumr}'";
	
}

for ($qrnumb = 1; $qrnumb <= $loop_num; $qrnumb++){
$mysqli->query(${'sqlr'.$qrnumb});

}

for ($sqlnum = 1; $sqlnum <= $loop_num; $sqlnum++){
	
	
	${'sql'.$sqlnum} = "INSERT INTO izzysales_orders(`order_id`, `customer_id`, `product_id`, `product_name`, `variant`, `unit`, `quantity`, `bill_amount`, `order_status`) 
VALUES ('".$order_id."', '".$customer_id."', '".${'product_id'.$sqlnum}."', '".${'prod_name'.$sqlnum}."','".${'variant'.$sqlnum}."','".${'unit'.$sqlnum}."','".${'quantity'.$sqlnum}."', '".${'prod_price'.$sqlnum}*${'quantity'.$sqlnum}."', '1')";

}
for ($qrnum = 1; $qrnum <= $loop_num; $qrnum++){
$mysqli->query(${'sql'.$qrnum});

}


$mysqli->close();

$url='../admin/new_sale.php';
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	

?>