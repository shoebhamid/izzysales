<?php
include('../../mysqli.php');

$prod_id = $mysqli -> real_escape_string($_POST['prod_id']);
$brand = $mysqli -> real_escape_string($_POST['brand']);
$hsn_code = $mysqli -> real_escape_string($_POST['hsn_code']);
$model = $mysqli -> real_escape_string($_POST['model']);
$color = $mysqli -> real_escape_string($_POST['color']);

$size = $mysqli -> real_escape_string($_POST['size']);
$volume = $mysqli -> real_escape_string($_POST['volume']);
$weight = $mysqli -> real_escape_string($_POST['weight']);
$length = $mysqli -> real_escape_string($_POST['length']);

$breadth = $mysqli -> real_escape_string($_POST['breadth']);
$height = $mysqli -> real_escape_string($_POST['height']);
$price = $mysqli -> real_escape_string($_POST['price']);
$discount_price = $mysqli -> real_escape_string($_POST['discount_price']);
$stock = $mysqli -> real_escape_string($_POST['stock']);
$min_sku = $mysqli -> real_escape_string($_POST['min_sku']);

include('../func/redirect.inc.php');

if(empty($prod_id)) {
	echo '<script>'.'alert("Please select valid product")'.'</script>';
	redirect_user("../admin/add_products.php");
	die();
}

$sql1 = "SELECT variant_num FROM izzysales_products_details WHERE goods_id = '$prod_id' ORDER BY variant_num DESC LIMIT 1";

$result = mysqli_query($mysqli, $sql1);
while($row = $result->fetch_assoc()) {
	$last_variant_num = $row['variant_num'];
	
}
$new_variant_num = $last_variant_num + 1;


$sql2 = "INSERT INTO izzysales_products_details(`goods_id`,`variant_num`, `color`, `length`, `breadth`, `height`, `size`, `weight`, `volume`, `brand`, `hsn_code`, `model`, `price`, `discount_price`, `stock`, `min_sku`) VALUES('".$prod_id."', '".$new_variant_num."', '".$color."', '".$length."', '".$breadth."', '".$height."', '".$size."', '".$weight."', '".$volume."', '".$brand."', '".$hsn_code."', '".$model."','".$price."','".$discount_price."', '".$stock."', '".$min_sku."')";


if (mysqli_query($mysqli, $sql2)) {
echo '<script>'.'alert("Variant added successfully")'.'</script>';	
redirect_user("../admin/add_products.php");
die();
  
}
















?>