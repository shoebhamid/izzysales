<?php
include('../../mysqli.php');
$user_first_name = $mysqli -> real_escape_string($_POST['user_first_name']);
$user_last_name = $mysqli -> real_escape_string($_POST['user_last_name']);
$user_email = $mysqli -> real_escape_string($_POST['user_email']);
$user_phone = $mysqli -> real_escape_string($_POST['user_phone']);
$user_id = $mysqli -> real_escape_string($_POST['user_id']);

if(!isset($user_id)) {
	echo 'Please select valid user id';
	die();
}


$sql="UPDATE izzysales_users SET fname='$user_first_name', lname='$user_last_name', email='$user_email', phone='$user_phone' WHERE user_id = '$user_id'";


if (mysqli_query($mysqli,$sql)){
echo '<script>';
echo 'alert("Changes saved")'; 
echo '</script>';
$url="../admin/profile.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
} else {
	echo "Error in saving changes";
}















?>