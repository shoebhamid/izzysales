<?php
include('../../mysqli.php');
$customer_name = $mysqli -> real_escape_string($_POST['customer_name']);
$customer_phone = $mysqli -> real_escape_string($_POST['customer_phone']);
$customer_email = $mysqli -> real_escape_string($_POST['customer_email']);
$customer_address = $mysqli -> real_escape_string($_POST['customer_address']);

include('../func/redirect.inc.php');

if(empty($customer_name)) {
	echo '<script>'.'alert("Please select valid customer name")'.'</script>';
	redirect_user("../admin/register_customer.php");
	die();
}


$sql1 = "SELECT customer_id FROM izzysales_customers ORDER BY customer_id DESC LIMIT 1";
$result = mysqli_query($mysqli, $sql1);
while($row = $result->fetch_assoc()) {
	$last_customer_id = $row['customer_id'];
}
$new_customer_id = $last_customer_id + 1;


$sql2 = "INSERT INTO izzysales_customers(`customer_id`, `customer_name`, `customer_email`, `customer_address`, `membership_status`) VALUES('".$new_customer_id."', '".$customer_name."', '".$customer_email."', '".$customer_address."', 'ACTIVE')";
if (mysqli_query($mysqli, $sql2)) {
echo '<script>'.'alert("Customer added successfully")'.'</script>';	
redirect_user("../admin/register_customer.php");
die();
  
}
















?>