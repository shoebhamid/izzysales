<?php
include('../../mysqli.php');
$goods_id = $mysqli -> real_escape_string($_POST['goods_id']);
$var_id = $mysqli -> real_escape_string($_POST['var_id']);

include('../func/redirect.inc.php');

if(empty($goods_id)) {
	echo '<script>'.'alert("Please select a product")'.'</script>';
	redirect_user("../admin/delete_products.php");
	die();
}


$sql="DELETE FROM izzysales_products_details WHERE goods_id = '$goods_id' && variant_num = '$var_id'";
$sql2="DELETE FROM izzysales_orders WHERE product_id = '$goods_id' && variant = '$var_id'";
$sql3="DELETE FROM izzysales_purchase_orders WHERE product_id = '$goods_id' && variant = '$var_id'";


if (mysqli_query($mysqli,$sql) && mysqli_query($mysqli,$sql2) && mysqli_query($mysqli,$sql3)){
	echo '<script>';
echo 'alert("Variant deleted")'; 
echo '</script>';
$url="../admin/delete_products.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';
} else {
	echo "Error deleting the variant";
}

?>