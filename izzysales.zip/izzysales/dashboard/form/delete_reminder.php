<?php
include('../../mysqli.php');

$id = $mysqli -> real_escape_string($_POST['reminder_id']);

include('../func/redirect.inc.php');

if(empty($id)) {
	echo '<script>'.'alert("Please select a reminder")'.'</script>';
	redirect_user("../admin/reminders.php");
	die();
}
$sql="DELETE FROM izzysales_reminders WHERE id = '$id'";

if (mysqli_query($mysqli,$sql)){
	echo '<script>';
echo 'alert("Reminder deleted")'; 
echo '</script>';
$url="../admin/reminders.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';
} else {
	echo "Error deleting the order";
}




?>