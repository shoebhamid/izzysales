<?php

include('../../mysqli.php');
$message = $mysqli -> real_escape_string($_POST['message']);
$user_id = $mysqli -> real_escape_string($_POST['usr_id']);

include('../func/redirect.inc.php');

if(empty($message)) {
	echo '<script>'.'alert("Please enter a reminder")'.'</script>';
	redirect_user("../admin/add_reminder.php");
	die();
}

$sql1 = "SELECT reminder_id FROM izzysales_reminders ORDER BY reminder_id DESC LIMIT 1";

$result = mysqli_query($mysqli, $sql1);
if (mysqli_num_rows($result) > 0) {

while($row = $result->fetch_assoc()) {
	$last_reminder_id = $row['reminder_id'];
	
}
} else {
	$last_reminder_id = 0;
}

$new_reminder_id = $last_reminder_id + 1;

$sql2 = "INSERT INTO izzysales_reminders(`user_id`, `reminder_id`, `reminder_message`) VALUES('".$user_id."', '".$new_reminder_id."', '".$message."')";


if (mysqli_query($mysqli, $sql2)) {
echo '<script>';
echo 'alert("Reminder added successfully")'; 
echo '</script>';
$url="../admin/reminders.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
  
}
















?>