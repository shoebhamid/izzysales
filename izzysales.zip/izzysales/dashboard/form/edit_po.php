<?php

include('../../mysqli.php');
$purchase_id = $mysqli -> real_escape_string($_POST['po_id']);
$supplier_id = $mysqli -> real_escape_string($_POST['supplier_id']);
$supplier_name = $mysqli -> real_escape_string($_POST['supplier_name']);
$product_id = $mysqli -> real_escape_string($_POST['product_id']);
$product_name = $mysqli -> real_escape_string($_POST['product_name']);
$variant = $mysqli -> real_escape_string($_POST['variant']);
$quantity = $mysqli -> real_escape_string($_POST['quantity']);
$unit = $mysqli -> real_escape_string($_POST['unit']);
$rate = $mysqli -> real_escape_string($_POST['rate']);
$paid_amount = $mysqli -> real_escape_string($_POST['paid_amount']);
$total_amount = $rate*$quantity;

include('../func/redirect.inc.php');

if(empty($purchase_id)) {
	echo '<script>'.'alert("Please enter valid details")'.'</script>';
	redirect_user("../admin/new_po.php");
	die();
}


$sql="UPDATE izzysales_purchase_orders SET supplier_id='$supplier_id', product_id='$product_id', variant='$variant', product_name='$product_name', rate='$rate', quantity = '$quantity', unit = '$unit', total_amount = '$total_amount',paid_amount = '$paid_amount' WHERE purchase_id = '$purchase_id'";


if (mysqli_query($mysqli,$sql)){
echo '<script>';
echo 'alert("Changes saved")'; 
echo '</script>';
$url="../admin/new_po.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
} else {
	echo "Error in saving changes";
}















?>