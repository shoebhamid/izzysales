<?php
include('../../mysqli.php');
$goods_name = $mysqli -> real_escape_string($_POST['goods_name']);
$goods_type = $mysqli -> real_escape_string($_POST['goods_type']);
$goods_unit = $mysqli -> real_escape_string($_POST['goods_unit']);
$goods_price = $mysqli -> real_escape_string($_POST['price']);
$goods_discount = $mysqli -> real_escape_string($_POST['discount']);
$goods_rating = $mysqli -> real_escape_string($_POST['rating']);
$goods_description = $mysqli -> real_escape_string($_POST['description']);

include('../func/redirect.inc.php');
if(empty($goods_name)) {
	echo '<script>'.'alert("Please enter valid goods name")'.'</script>';
	redirect_user("../admin/add_products.php");
	die();
}

$sql1 = "SELECT goods_id FROM izzysales_products ORDER BY goods_id DESC LIMIT 1";
$result = mysqli_query($mysqli, $sql1);
while($row = $result->fetch_assoc()) {
	$last_goods_id = $row['goods_id'];
}
$new_goods_id = $last_goods_id + 1;


$sql2 = "INSERT INTO izzysales_products(`goods_id`, `goods_name`, `goods_type`, `goods_unit`, `goods_price`, `goods_discount`,`goods_rating`,`goods_description`) VALUES('".$new_goods_id."', '".$goods_name."', '".$goods_type."', '".$goods_unit."', '".$goods_price."', '".$goods_discount."', '".$goods_rating."', '".$goods_description."')";

$sql3 ="INSERT INTO izzysales_products_details(`goods_id`, `price`, `discount_price`, `variant_num`) VALUES('".$new_goods_id."', '".$goods_price."', '".$goods_discount."','1')";


if (mysqli_query($mysqli, $sql2) && mysqli_query($mysqli, $sql3)) {
echo '<script>';
echo 'alert("Product added successfully")'; 
echo '</script>';
$url="../admin/add_products.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
  
}
















?>