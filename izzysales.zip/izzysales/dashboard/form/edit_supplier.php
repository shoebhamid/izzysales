<?php

include('../../mysqli.php');
$supplier_id = $mysqli -> real_escape_string($_POST['supplier_id']);
$supplier_name = $mysqli -> real_escape_string($_POST['supplier_name']);
$person_name = $mysqli -> real_escape_string($_POST['person_name']);
$contact_num = $mysqli -> real_escape_string($_POST['contact_num']);
$address = $mysqli -> real_escape_string($_POST['address']);
$gst = $mysqli -> real_escape_string($_POST['gst']);
$credit = $mysqli -> real_escape_string($_POST['credit']);
$debit = $mysqli -> real_escape_string($_POST['debit']);


include('../func/redirect.inc.php');

if(!isset($supplier_name)) {
	echo '<script>'.'alert("Please select valid Supplier Name")'.'</script>';
	redirect_user("../admin/add_supplier.php");
	die();
}


if($credit ==""){
	$credit = 0;
}
if($debit ==""){
	$debit = 0;
}

$sql="UPDATE izzysales_suppliers SET supplier_name='$supplier_name', supplier_phone='$contact_num', supplier_address = '$address', supplier_contact = '$person_name', supplier_gst = '$gst',supplier_credit = '$credit',supplier_debit = '$debit' WHERE supplier_id = '$supplier_id'";


if (mysqli_query($mysqli,$sql)){
echo '<script>'.'alert("Changes saved")'.'</script>';
redirect_user("../admin/add_supplier.php");
die();
} else {
	echo "Error in saving changes";
	redirect_user("../admin/add_supplier.php");
    die();
}















?>