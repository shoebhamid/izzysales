<?php

//$image1="../content/product_images/full_1713951245.jpg";
//unlink($image1);


//die();
$prod_id = $_POST['prod_id'];
if (!preg_match('/^[0-9]*$/',$prod_id)) {
	echo "Wrong details";
	die();
}

include('../../mysqli.php');
$sql="DELETE FROM izzysales_orders WHERE product_id = '$prod_id'";
$sql2="DELETE FROM izzysales_products_details WHERE goods_id = '$prod_id'";
$sql3="DELETE FROM izzysales_products_images WHERE product_id = '$prod_id'";
$sql4="DELETE FROM izzysales_purchase_orders WHERE product_id = '$prod_id'";
$sql5="DELETE FROM izzysales_products WHERE goods_id = '$prod_id'";

if (mysqli_query($mysqli,$sql) && mysqli_query($mysqli,$sql2) && mysqli_query($mysqli,$sql3) && mysqli_query($mysqli,$sql4) && mysqli_query($mysqli,$sql5)){
	echo '<script>';
echo 'alert("Product deleted")'; 
echo '</script>';
$url="../admin/products.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';
} else {
	echo "Error deleting the product";
}


?>