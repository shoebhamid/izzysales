<?php
date_default_timezone_set("Asia/Kolkata");
$date1 = date("Y-m-d H:i:s");
$date3=date_create($date1);
$month = substr($date1,5,2);
$year = substr($date1,0,4);


$day = '01';
$time = '00:00:00';
$time2 = '23:59:59';

$start_date = $year.'-'.$month.'-'.$day.' '.$time;
$end_date = $date1;

$date1_n = new DateTime($start_date);
$date1_only = $date1_n->format('d-m-Y');

$date2_n = new DateTime($end_date);
$date2_only = $date2_n->format('d-m-Y');


?>