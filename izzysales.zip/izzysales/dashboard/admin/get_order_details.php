<?php session_start();
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_orders WHERE order_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     
}

$mysqli->close();
?>

<div class="row" style="margin-bottom:8px" id="supp_name">
	<div class="col-lg-5" style="padding: 0px 3px 0px 15px !Important;">
	<input type="text" class="form-control input-default" name="customer_name" placeholder="CUSTOMER NAME"> 
	</div>
</div>
<?php $serial = 1;?>
<?php foreach($result as $result) :?>

<div class="row" style="margin-bottom:8px" id="supp_name">
<div class="col-lg-4">
			   <select class="form-control input-default" id="prod_name<?php echo $serial;?>" name="prod_name<?php echo $serial;?>">
				<?php include('get_products_list.php');?>
				<option value="<?php echo $result['product_id'];?>" selected><?php echo $result['product_name'];?></option>
			   </select>
			</div>
			<input type="hidden" name="old_prod_id<?php echo $serial;?>" value="<?php echo $result['product_id'];?>">
			<input type="hidden" name="old_id<?php echo $serial;?>" value="<?php echo $result['id'];?>">
			<div class="col-lg-2">
			   <input type="number" min="1" class="form-control input-default" name="variant<?php echo $serial;?>" placeholder="VARIANT" value="<?php echo $result['variant'];?>"> 
			</div>	
          <input type="hidden" name="old_variant<?php echo $serial;?>" value="<?php echo $result['variant'];?>">			
			<div class="col-lg-2">
			   <select class="form-control input-default" name="unit<?php echo $serial;?>">
				<option value="NOS">NOS</option>
				<option value="KGS">KGS</option>
				<option value="LITRES">LITRES</option>
				<option value="METRES">METRES</option>
				<option value="<?php echo $result['unit'];?>" selected><?php echo $result['unit'];?></option>
			   </select> 
			</div>
			<div class="col-lg-2">
			   <input type="number" class="form-control input-default" name="quantity<?php echo $serial;?>" placeholder="QUANTITY" value="<?php echo $result['quantity'];?>"> 
			</div>
			<div class="col-lg-2">
			   <input type="number" class="form-control input-default" name="bill_amount<?php echo $serial;?>" placeholder="PRICE" value="<?php echo $result['bill_amount']/$result['quantity'];?>"> 
			</div>
			<input type="hidden" name="total_serial" value="<?php echo $serial;?>">
			
<?php $serial = $serial+1;?>	

	</div>

<?php endforeach;?>	
	
<div class="row" style="margin-bottom:8px">	
	
	
	<div class="col-lg-4">
	   <button type="submit" class="btn btn-primary">SAVE</button>
	</div>

</div>   
<script>

</script>