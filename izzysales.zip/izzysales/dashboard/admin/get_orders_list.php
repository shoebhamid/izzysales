<?php
include('../../mysqli.php');
$query1 = "SELECT DISTINCT order_id FROM izzysales_orders WHERE order_status='0'";
$result1 = mysqli_query($mysqli, $query1);

?>

<?php foreach($result1 AS $result1):
	echo '<option value="'.$result1['order_id'].'">'.$result1['order_id'].'</option>';
endforeach;

?>
