<?php session_start();
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_purchase_orders WHERE purchase_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     $supplier_id=$row['supplier_id'];
	 $product_id=$row['product_id'];
	 $variant= $row['variant'];
	 $product_name=$row['product_name'];
	 $rate=$row['rate'];
	 $quantity=$row['quantity'];
	 $unit=$row['unit'];
	 $total_amount=$row['total_amount'];
	 $paid_amount = $row['paid_amount'];
}

$sql2="SELECT supplier_name FROM izzysales_suppliers WHERE supplier_id = '".$supplier_id."'";
$result2 = mysqli_query($mysqli,$sql2);
while($row2 = mysqli_fetch_array($result2)) {
     $supplier_name=$row2['supplier_name'];
}




$mysqli->close();
?>


<?php $serial = 1;?>
<?php foreach($result as $result) :?>

<div class="row" style="margin-bottom:8px" id="supp_name">
<div class="col-lg-4">
<select class="form-control input-default" name="supplier_id" disabled>
               <?php 
			   include('../../mysqli.php');
					$query1 = "SELECT DISTINCT supplier_name, supplier_id FROM izzysales_suppliers";
					$result1 = mysqli_query($mysqli, $query1);

					foreach($result1 AS $result1):
						echo '<option value="'.$supplier_name.'" selected hidden>'.$supplier_name.'</option><option value="'.$result1['supplier_id'].'">'.$result1['supplier_name'].'</option>';
					endforeach;?>
					</select>
			</div>
			
			<div class="col-lg-3">
			   <select class="form-control input-default" id="prod_name" name="product_name1" disabled>
			   
				<?php include('get_products_list.php');?>
				<option value="<?php echo $product_name;?>" selected hidden><?php echo $product_name;?></option>
			   </select>
			</div>	
			
			
			<div class="col-lg-2">
			
			   <input type="number" min="1" class="form-control input-default" name="variant" placeholder="VARIANT" value="<?php echo $variant;?>" readonly> 
			</div>	
			
			</div>
			<div class="row">
						
			<div class="col-lg-2">
			
			   <input type="number" class="form-control input-default" name="quantity1" value="<?php echo $quantity;?>" readonly> 
			</div>
			<div class="col-lg-2">
			
			   <select class="form-control input-default" name="unit1" disabled>
				<option value="NOS">NOS</option>
				<option value="KGS">KGS</option>
				<option value="LITRES">LITRES</option>
				<option value="METRES">METRES</option>
				<option value="<?php echo $unit;?>" selected hidden><?php echo $unit;?></option>
			   </select> 
			</div>
			<div class="col-lg-2">
			
			   <input type="number" class="form-control input-default" name="rate" value="<?php echo $total_amount/$quantity;?>" readonly> 
			</div>
			<div class="col-lg-2">
			
			   <input type="number" class="form-control input-default" name="paid_amount" value="<?php echo $paid_amount;?>" readonly> 
			</div>
			<div class="col-lg-2">
			<input type="hidden" name="po_id" value="<?php echo $q;?>">
			<button type ="submit" class="btn btn-primary" >DELETE</button>
			</div>
	   	    </div>

	</div>

<?php endforeach;?>	
	
