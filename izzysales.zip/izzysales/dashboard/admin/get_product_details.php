<?php
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_products_details WHERE goods_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     $variant_id = $row['variant_num'];
}

$mysqli->close();
?>

<form method="POST" action="../form/add_product_variant.php">
<div class="row" style="margin-bottom:8px" id="supp_name">
<div class="col-lg-2" style="padding: 0px 3px 0px 15px !Important;">
	   <input type="text" class="form-control input-default" name="brand" placeholder="BRAND NAME"> 
	</div>
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="hsn_code" placeholder="HSN CODE"> 
	</div>
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="model" placeholder="MODEL"> 
	</div>
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="color" placeholder="COLOR">
	</div>
	
	<div class="col-lg-2" style="padding: 0px 15px 0px 3px!Important;">
	  <input type="text" class="form-control input-default" name="size" placeholder="SIZE">
	</div>
	<div class="col-lg-2" style="padding: 0px 15px 0px 3px!Important;">
	  <input type="text" class="form-control input-default" name="volume" placeholder="VOL">
	</div>
    </div>   

<div class="row" style="margin-bottom:8px">	
	<div class="col-lg-2" style="padding: 0px 3px 0px 15px !Important;">
	   <input type="text" class="form-control input-default" name="weight" placeholder="WEIGHT">
	</div>
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="length" placeholder="LENGTH">
	</div>
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="breadth" placeholder="BREADTH">
	</div>
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="height" placeholder="HEIGHT">
	</div>
	
	<div class="col-lg-2" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="price" placeholder="PRICE" required>
	</div>
	<div class="col-lg-2" style="padding: 0px 15px 0px 3px!Important;">
	   <input type="text" class="form-control input-default" name="discount_price" placeholder="DISCOUNT">
	</div>		
	
		
	</div>
	
	<div class="row" style="margin-bottom:8px">	
	<div class="col-lg-2" style="padding: 0px 3px 0px 15px !Important;">
	   <input type="text" class="form-control input-default" name="stock" placeholder="ADD STOCK" required>
	</div>	
	<div class="col-lg-2" style="padding: 0px 3px 0px 15px !Important;">
	   <input type="text" class="form-control input-default" name="min_sku" placeholder="MIN SKU" required>
	</div>
	</div>
<div class="row" style="margin-bottom:8px">	
	<input type="hidden" name="prod_id" value="<?php echo $q;?>">
	
	<div class="col-lg-4">
	   <button type="submit" class="btn btn-primary">SAVE</button>
	</div>
</form>	
</div>   

<form method="POST" action="../form/edit_product_variant.php">
<div class="row" style="margin-bottom:8px; margin-top:30px">	
	<span style="margin-left:10px"><i class="fa fa-check" style="padding-right:15px"></i></span><span class="accordion__header--text" style="margin-bottom:5px">ALL VARIANTS</span>
<!-- Datatable -->
       <table class="table table-light table-hover table-sm" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:10px">

            <thead>
                <tr class="table-success">
                   
					            <th class="" data-column="be_out_hr_mod">V.No</th>
								<th class="" data-column="be_out_hr_mod">BRAND</th>
								<th class="" data-column="be_out_hr_mod">HSN</th>
								<th class="" data-column="be_out_hr_mod">COLOR</th>
								<th class="" data-column="be_out_hr_mod">SIZE</th>
								<th class="" data-column="be_out_hr_mod">WEIGHT</th>
								<th class="" data-column="be_out_hr_mod">VOL</th>
								<th class="" data-column="be_out_hr_mod">LENGTH</th>
								<th class="" data-column="be_out_hr_mod">BREADTH</th>
								<th class="" data-column="be_out_hr_mod">HEIGHT</th>
								<th class="" data-column="be_out_hr_mod">model</th>
								<th class="" data-column="be_out_hr_mod">PRICE</th>
								<th class="" data-column="be_out_hr_mod">DISCOUNT</th>
								<th class="" data-column="be_out_hr_mod">STOCK</th>
								<th class="" data-column="be_out_hr_mod">SKU</th>
								<th class="" data-column="be_out_hr_mod"></th>
								
                </tr>
            </thead>
            <tbody>
		
                <?php foreach($result as $result): ?>
					
				<?php $sr_num = $result['variant_num'];?>
				
                <tr>
                    <td><input type="number" style="font-size:11px" class="form-control input-default" name="var_serial" value="<?php echo $sr_num;?>" readonly></td>
					
					<td><input type="text" style="font-size:11px" class="form-control input-default" name="brand_var" value="<?php echo $result['brand'];?>"></td>
					
					
					<td><input type="text" style="font-size:11px" class="form-control input-default" name="hsn_var" value="<?php echo $result['hsn_code'];?>"></td>
                   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="color_var" value="<?php echo $result['color'];?>"></td>
				   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="size_var" value="<?php echo $result['size'];?>"></td>
				   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="weight_var" value="<?php echo $result['weight'];?>"></td>
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="vol_var" value="<?php echo $result['volume'];?>"></td>
                <td><input type="text" style="font-size:11px" class="form-control input-default" name="length_var" value="<?php echo $result['length'];?>"></td>
				
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="breadth_var" value="<?php echo $result['breadth'];?>"></td>
				
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="height_var" value="<?php echo $result['height'];?>"></td>
				
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="model_var" value="<?php echo $result['model'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="price_var" value="<?php echo $result['price'];?>"></td>
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="discount_price_var" value="<?php echo $result['discount_price'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="stock_var" value="<?php echo $result['stock'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="sku_var" value="<?php echo $result['min_sku'];?>"></td>
				
				<td><input type="submit" style="font-size:11px" class="btn-primary form-control input-default" value="UPDATE"</td>
				</tr>
				
				<input type="hidden" name="goods_id" value="<?php echo $q;?>">	
                <input type="hidden" name="var_id" value="<?php echo $result['variant_num'];?>">		
</form>					
                <?php endforeach; ?>
		        
				
				</tbody>
        </table>
                 
				 
</div>   

