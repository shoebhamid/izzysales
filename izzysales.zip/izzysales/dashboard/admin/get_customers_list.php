<?php
include('../../mysqli.php');
$query1 = "SELECT * FROM izzysales_customers WHERE customer_name !=''";
$result1 = mysqli_query($mysqli, $query1);

?>

<?php foreach($result1 AS $result1):
	echo '<option value="'.$result1['customer_id'].'">'.$result1['customer_name'].'</option>';
endforeach;

?>
