<?php
include('../../mysqli.php');
$query1 = "SELECT * FROM izzysales_suppliers";
$result1 = mysqli_query($mysqli, $query1);

?>

<?php foreach($result1 AS $result1):
	echo '<option value="'.$result1['supplier_id'].'">'.$result1['supplier_name'].'</option>';
endforeach;

?>
