<?php
include('../../mysqli.php');
$query1 = "SELECT * FROM izzysales_products";
$result1 = mysqli_query($mysqli, $query1);

?>

<?php foreach($result1 AS $result1):
	echo '<option value="" style="display:none">PRODUCT NAME</option> <option value="'.$result1['goods_id'].'">'.$result1['goods_name'].'</option>';
endforeach;

?>
