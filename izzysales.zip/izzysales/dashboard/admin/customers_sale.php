<?php session_start();
include('session.php'); 
include('../../mysqli.php');

$query1 = "SELECT * FROM izzysales_users WHERE user_id = '$logged_user_id'";
$result1 = mysqli_query($mysqli, $query1);

if (mysqli_num_rows($result1) > 0) {
     while($row = mysqli_fetch_assoc($result1)) {
        $usr_dp_pic= $row["image"];
		$userfullname = $row["fname"];
    }
} else {
    $usr_dp_pic = 'default.png';
}

$query2 = "SELECT * FROM izzysales_settings";
$result2 = mysqli_query($mysqli, $query2);
     while($row = mysqli_fetch_assoc($result2)) {
        $company_name= $row["company_name"];
		
    }
 
$mysqli->close();

include('../func/pdo.inc.php');
  
  // MySQL Query
  $sqlquery = "SELECT izzysales_customers.customer_name, izzysales_orders.order_id, izzysales_orders.bill_amount, izzysales_orders.date  
  FROM izzysales_customers 
  INNER JOIN izzysales_orders ON izzysales_orders.customer_id=izzysales_customers.customer_id
  WHERE izzysales_customers.customer_name !='' 
  ORDER BY izzysales_customers.customer_name DESC LIMIT $paginationStart, $limit";
  //echo $sqlquery;
  $sqlquery2 = "SELECT count(id) AS id FROM `izzysales_customers` WHERE customer_name != ''";
 
 // Fetch Rows 
  $entries = $connection->query("$sqlquery")->fetchAll();
  $res = $connection->query($sqlquery);
  $allRecrods = $res->rowCount();
 
  
  // Calculate total pages
  $totoalPages = ceil($allRecrods / $limit);
  // Prev + Next
  $prev = $page - 1;
  $next = $page + 1;

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>izzysales CUSTOMERS SALE </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ME_URI;?>images/favicon.png">
    <link href="<?php echo ME_URI;?>css/style.css" rel="stylesheet">

</head>

<script>
function getSale(str) {
  if (str=="") {
    document.getElementById("customer_name").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("get_details").innerHTML=this.response;
	  
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","get_customer_sale.php?q="+str,true);
  xmlhttp.send();
}

</script>


<body>
<?php include('../../nav_header.php');?>

<?php include('sidebar.php');?> 

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12">
				
					
			<div class="col-lg-12">
        <div class="row" style="margin-top:10px;">
		<div class="col-lg-7">
		<h4 style="margin:10px 0px 10px 10px; padding:5px; font-size:18px"><span><i class="fa fa-bar-chart" aria-hidden="true"></i> </span>CUSTOMERS' SALE</h4>
		</div>
		<div class="col-lg-5">
		<div class="d-flex flex-row-reverse bd-highlight mb-3" style="padding-bottom: 5px;">
            <form action="customers_sale.php" method="GET" id="rec_form">
                <select name="records-limit" id="records-limit" class="custom-select">
                    <option disabled selected>Records Limit</option>
                    <?php foreach([10, 20, 50, 100] as $limit) : ?>
                    <option
                        <?php if(isset($_SESSION['records-limit']) && $_SESSION['records-limit'] == $limit) echo 'selected'; ?>
                        value="<?= $limit; ?>">
                        <?= $limit; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
		</div>
		</div>
        <!-- Datatable -->
       <table class="table table-light table-striped table-hover" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:14px">

            <thead>
                <tr class="table-success">
                   
					            <th class="" data-column="be_out_hr_mod">CUSTOMER</th>
								<th class="" data-column="be_out_hr_mod">ORDER ID</th>
								<th class="" data-column="be_out_hr_mod">DATE</th>
								<th class="" data-column="be_out_hr_mod">BILL</th>
								
								
                </tr>
            </thead>
            <tbody>
			
                <?php foreach($entries as $entries): ?>
				
							
				
                <tr>
                    <td scope="row"><?php echo $entries['customer_name']; ?></td>
					<td><a href="order_details.php?order_id=<?php echo $entries['order_id']; ?>"><?php echo $entries['order_id']; ?></a></td>
					<td><?php echo $entries['date']; ?></td>
                    <td><?php echo $entries['bill_amount']; ?></td>
                    
					
					
                </tr>
							
                <?php endforeach;?>
				
				</tbody>
        </table>
        <!-- Pagination -->
        <nav aria-label="Page navigation example mt-5">
            <ul class="pagination">
                <li class="page-item <?php if($page <= 1){ echo 'disabled'; } ?>">
                    <a class="page-link"
                        href="<?php if($page <= 1){ echo '#'; } else { echo "?page=" . $prev; } ?>">Previous</a>
                </li>
                <?php for($i = 1; $i <= $totoalPages; $i++ ): ?>
                <li class="page-item <?php if($page == $i) {echo 'active'; } ?>">
                    <a class="page-link" href="customers_sale.php?page=<?= $i; ?>"> <?= $i; ?> </a>
                </li>
                <?php endfor; ?>
                <li class="page-item <?php if($page >= $totoalPages) { echo 'disabled'; } ?>">
                    <a class="page-link"
                        href="<?php if($page >= $totoalPages){ echo '#'; } else {echo "?page=". $next; } ?>">Next</a>
                </li>
            </ul>
        </nav>

    <!-- jQuery + Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#records-limit').change(function () {
				$("#rec_form").submit();
                //$('form').submit();
            })
        });
    </script>
	




		
		</div>
		
		
		
		
		
						<div class="col-lg-12">
					<div class="row" style="margin-top:10px;">
						<div class="col-lg-7">
						
						</div>
						
						<div class="col-lg-5">
						
						</div>
					</div>        
					
					<!-- Body Content -->
		<div class="row">		
		<div class="col-lg-12">
		<form action="../form/edit_reg_customer.php" method = "POST">
	   <div style="margin-top:15px; margin-bottom:25px">    
       <div id="accordion-two" class="accordion" style="background:#e7ebed">
          <div class="accordion__item">
				<div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapsetwo" style="background: #e5e373;border: 1px solid #d6c95d;">
					<span><i class="fa fa-search" style="padding-right:10px"></i></span><span class="accordion__header--text">SEARCH BY CUSTOMER</span>
					<span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
				</div>
					<div id="collapsetwo" class="collapse accordion__body" data-parent="#accordion-two">
						<div class="accordion__body--text">
           
<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   
	      <select class="form-control input-default" id = "customer_name" name="customer_name" onchange="getSale(this.value)">
<?php
include('../../mysqli.php');
$query1 = "SELECT * FROM izzysales_customers WHERE customer_name !=''";
$result1 = mysqli_query($mysqli, $query1);

?>

<?php foreach($result1 AS $result1):
	echo '<option value="'.$result1['customer_id'].'">'.$result1['customer_name'].'</option>';
endforeach;

?>
	   </select>
	   
	   
	   
	</div>
	<div class="col-lg-8">
	   
	</div>
    </div>   
		   
	
	
	<div id="get_details">

	</div>

</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
</div>

</div>
		</div>			
									
			</div>   
		</div>
					
					

	</div>

        <!--**********************************
            Content body end
        ***********************************-->

 <!--**********************************
            Footer start
        ***********************************-->
        
		<div class="row">
		<div class="col-lg-12">
		<div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        



<script src="../../vendor/global/global.min.js"></script>
<script src="../../js/custom.min.js"></script>
    </div>
 </div>
</body>

</html>