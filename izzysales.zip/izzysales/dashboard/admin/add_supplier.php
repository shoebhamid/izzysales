<?php session_start();
include('session.php'); 
include('../../mysqli.php');

$query1 = "SELECT * FROM izzysales_users WHERE user_id = '$logged_user_id'";
$result1 = mysqli_query($mysqli, $query1);

if (mysqli_num_rows($result1) > 0) {
     while($row = mysqli_fetch_assoc($result1)) {
        $usr_dp_pic= $row["image"];
		$userfullname = $row["fname"];
    }
} else {
    $usr_dp_pic = 'default.png';
}

$query2 = "SELECT * FROM izzysales_settings";
$result2 = mysqli_query($mysqli, $query2);
     while($row = mysqli_fetch_assoc($result2)) {
        $company_name= $row["company_name"];
		
    }
 
$mysqli->close();

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>izzysales ADD SUPPLIER </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ME_URI;?>images/favicon.png">
    <link href="<?php echo ME_URI;?>css/style.css" rel="stylesheet">

</head>

<body>
<?php include('../../nav_header.php');?>

<?php include('sidebar.php');?> 

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script>
function getSupplier(str) {
  if (str=="") {
    document.getElementById("supp_name").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("get_details").innerHTML=this.response;
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","get_supp_details.php?q="+str,true);
  xmlhttp.send();
}

</script>
        <!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
	<div class="container-fluid">
		<div class="row" style="min-height:640px">
			<div class="col-xl-12 col-lg-12 col-md-12">
				
					
				<div class="col-lg-12">
					<div class="row" style="margin-top:10px;">
						<div class="col-lg-7">
						
						</div>
						
						<div class="col-lg-5">
						
						</div>
					</div>        
					
					<!-- Body Content -->
		<div class="row">		
		<div class="col-lg-12">
		<form action="../form/add_supplier.php" method = "POST">
	   <div style="margin-top:10px; margin-bottom:25px">    
       <div id="accordion-one" class="accordion" style="background:#e7ebed">
                                    <div class="accordion__item">
                                        <div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapseone" style="background: #e5e373;border: 1px solid #d6c95d;">
                                            <span><i class="fa fa-user" style="padding-right:15px"></i></span><span class="accordion__header--text">ADD NEW SUPPLIER</span>
                                            <span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
                                        </div>
                                        <div id="collapseone" class="collapse accordion__body" data-parent="#accordion-one">
                                            <div class="accordion__body--text">
                                           
	<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="supplier_name" placeholder="SUPPLIER NAME" required> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="person_name" placeholder="CONTACT PERSON"> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="contact_num" placeholder="PHONE" > 
	</div>
    </div>   

<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="address" placeholder="ADDRESS"> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="gst" placeholder="GST/TAX NUMBER"> 
	</div>
	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="credit" placeholder="CREDIT"> 
	</div>	
	
    </div>   
	
<div class="row" style="margin-bottom:8px">	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="debit" placeholder="DEBIT"> 
	</div>
	
<div class="col-lg-4">
	   <button type="submit" class="btn btn-primary">ADD</button>
	</div>
	
	<div class="col-lg-4">
	  
	</div>
</div>
</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
</div>

</div>


	
				<div class="col-lg-12">
					<div class="row" style="margin-top:10px;">
						<div class="col-lg-7">
						
						</div>
						
						<div class="col-lg-5">
						
						</div>
					</div>        
					
					<!-- Body Content -->
		<div class="row">		
		<div class="col-lg-12">
		<form action="../form/edit_supplier.php" method = "POST">
	   <div style="margin-top:15px; margin-bottom:25px">    
       <div id="accordion-two" class="accordion" style="background:#e7ebed">
          <div class="accordion__item">
				<div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapsetwo" style="background: #e5e373;border: 1px solid #d6c95d;">
					<span><i class="fa fa-edit" style="padding-right:10px"></i></span><span class="accordion__header--text">EDIT SUPPLIER</span>
					<span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
				</div>
					<div id="collapsetwo" class="collapse accordion__body" data-parent="#accordion-two">
						<div class="accordion__body--text">
           
<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   
	      <select class="form-control input-default" name="supplier_name" onchange="getSupplier(this.value)" size="2">
	    <?php include('get_suppliers_list.php');?>
	   </select>
	   
	   
	   
	</div>
	<div class="col-lg-8">
	   
	</div>
    </div>   
		   
	
	
	<div id="get_details">

	</div>

</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
</div>

</div>

</div>
</div>
</div>
</div>
        <!--**********************************
            Content body end
        ***********************************-->

 <!--**********************************
            Footer start
        ***********************************-->
        
		<div class="row">
		<div class="col-lg-12">
		<div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        



<script src="../../vendor/global/global.min.js"></script>
<script src="../../js/custom.min.js"></script>
    </div>
 </div>
</body>

</html>