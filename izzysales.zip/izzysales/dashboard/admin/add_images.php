<?php session_start();
include('session.php'); 
include('../../mysqli.php');

$query1 = "SELECT * FROM izzysales_users WHERE user_id = '$logged_user_id'";
$result1 = mysqli_query($mysqli, $query1);

if (mysqli_num_rows($result1) > 0) {
     while($row = mysqli_fetch_assoc($result1)) {
        $usr_dp_pic= $row["image"];
		$userfullname = $row["fname"];
    }
} else {
    $usr_dp_pic = 'default.png';
}

$query2 = "SELECT * FROM izzysales_settings";
$result2 = mysqli_query($mysqli, $query2);
     while($row = mysqli_fetch_assoc($result2)) {
        $company_name= $row["company_name"];
		
    }
	

ini_set('memory_limit','128M');

include('../../config.php');

    $_SESSION['random_key'] = strtotime(date('Y-m-d H:i:s')); //assign the timestamp to the session variable
	//$_SESSION['user_file_ext']= "";

$userfullname=$logged_user_fname." ".$logged_user_lname;
$userfullname=ucwords($logged_user_fname)." ".ucwords($logged_user_lname);
$logged_user_id = $_SESSION["user_id"];

    global $user_id;
	$user_id=$_SESSION["user_id"];
	
	
      $imgnm = '../content/product_images/' . 'default.png';
			
   if (!isset($_GET['reply']))
          {
          $_GET['reply']="";
          }     
      $photo_id= $_SESSION['random_key'];
	  $usr_id= $_SESSION["user_id"]; 
	  $ful_img_uri = "full_".$photo_id.".jpg";
	  $thmb_img_uri = "thumb_".$photo_id.".jpg";
	  
	   //pass on the values in session;
	  unset($_SESSION["photo_id_s"]);
	  unset($_SESSION["usr_id_s"]);
	  unset($_SESSION["ful_img_uri_s"]);
	
	   $_SESSION["photo_id_s"] = $photo_id;
	   $_SESSION["usr_id_s"] = $usr_id;
	   $_SESSION["ful_img_uri_s"] = $ful_img_uri;
	  
	  
	  //$imgnm = $imgnm.$ful_img_uri;
	

   
   if(isset($_POST["image"]))
{
	$imgnm = $imgnm.$ful_img_uri;
}	
	
 
$mysqli->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
 <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ME_URI;?>images/favicon.png">
    <link href="<?php echo ME_URI;?>css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo ME_URI;?>dist/js/jquery.imgareaselect.min.js" type="text/javascript"></script>	
<link rel="stylesheet" href="<?php echo ME_URI;?>dist/css/dropzone.css" />
<link href="<?php echo ME_URI;?>dist/css/cropper.css" rel="stylesheet"/>
<script src="<?php echo ME_URI;?>dist/js/dropzone.js"></script>
<script src="<?php echo ME_URI;?>dist/js/cropper.js"></script>

</head>
		
		
<style>

.image_area {
  position: relative;
}

img {
	display: block;
	max-width: 100%;
}

.preview {
	overflow: hidden;
	width: 160px; 
	height: 160px;
	margin: 10px;
	border: 1px solid red;
}

.modal-lg{
	max-width: 1000px !important;
}

.overlay {
  position: absolute;
  bottom: 10px;
  left: 0;
  right: 0;
  background-color: rgba(255, 255, 255, 0.5);
  overflow: hidden;
  height: 0;
  transition: .5s ease;
  width: 100%;
}

.image_area:hover .overlay {
  height: 50%;
  cursor: pointer;
}

.text {
  color: #333;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  text-align: center;
}

</style>



<body>
<?php include('../../nav_header.php');?>

<?php include('sidebar.php');?> 

        <!--**********************************
            Content body start
        ***********************************-->
<script>
function getImages(str) {
  if (str=="") {
    document.getElementById("images_list").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("get_images").innerHTML=this.response;
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","get_product_images.php?q="+str,true);
  xmlhttp.send();
}

</script>		
		
		
<div class="content-body">
	 <div class="container">
           

	
	
	
           <div class="row" style="margin:8px;">
                    

	<div class="col-md-12" style="padding: 20px; text-align:center">
	
	<div class="row">
    
				<div class="col-md-12">
				    
				    			    
					<div class="image_area">
						<form method="post">
							<label for="upload_image" style="padding:10px;">
								<img src="<?php echo $imgnm;?>" id="uploaded_image" class="img-responsive" style="max-width:200px"/>
								
			    				<input type="file" name="image" class="image" id="upload_image" style="display:none">
								
			    			</label>
			    		</form>
			    	</div>
			    </div>
    		<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true" style="width:90%;">
			  	<div class="modal-dialog modal-lg" role="document">
			    	<div class="modal-content">
			      		<div class="modal-header">
			        		<h5 class="modal-title" id="modalLabel">Crop Image Before Upload</h5>
							
			        		<button type="button" class="close" data-dismiss="modal" aria-label="Close">
			          			<span aria-hidden="true">×</span>
			        		</button>
							
			      		</div>
			      		<div class="modal-body">
			        		<div class="img-container">
			            		<div class="row">
			                		<div class="col-md-8">
			                    		<img src="" id="sample_image" />
			                		</div>
			                		<div class="col-md-4">
			                    		<div class="preview"></div>
			                		</div>
			            		</div>
			        		</div>
			      		</div>
			      		<div class="modal-footer">
						  <p>Use only JPEG, PNG (less than 5MB). If image is not uploaded or cropped, pls refresh the page</p>
			        		<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
			        		<button type="button" class="btn btn-primary" id="crop">Crop</button>
			        		<a class="btn btn-warning" href="upload_photo.php" role="button">Refresh</a>
							
			      		</div>
			    	</div>
			  	</div>
			</div>			
		</div>
		
		
<script>

$(document).ready(function(){


	
	var $modal = $('#modal');
	var image = document.getElementById('sample_image');
	var cropper;

	
	$('#upload_image').change(function(event){
    	var files = event.target.files;
    	var done = function (url) {
      		image.src = url;
      		$modal.modal('show');
    	};
    	

    	if (files && files.length > 0)
    	{
      		
        		reader = new FileReader();
		        reader.onload = function (event) {
		          	done(reader.result);
		        };
        		reader.readAsDataURL(files[0]);
      		
    	}
	});

	$modal.on('shown.bs.modal', function() {
    	cropper = new Cropper(image, {
    		aspectRatio: 1.5,
    		viewMode: 1,
    		preview: '.preview'
    	});
	}).on('hidden.bs.modal', function() {
   		cropper.destroy();
   		cropper = null;
	});

	$("#crop").click(function(){
    	canvas1 = cropper.getCroppedCanvas({
      		width: 300,
      		height: 200,
    	});
		
    	canvas1.toBlob(function(blob) {
        	
        	var reader = new FileReader();
         	reader.readAsDataURL(blob); 
         	reader.onloadend = function() {
            	var base64data = reader.result;  
            
            	$.ajax({
            		url: "upload_image.php",
                	method: "POST",                	
                	data: {image: base64data},
                	success: function(data){
                    	console.log(data);
                    	$modal.modal('hide');
                    	$('#uploaded_image').attr('src', data);
                    	//alert("success upload image");
						//window.location.href="upload_photo.php";
                	}
              	});
         	}
    	});
		
		
    });
    
    $("#imge-details").click(function(event){
        $.post("validate_photo_details.php", $('#photo-details').serialize(), function(data){
		$("#form-result").html(data);
		     });

		  });
		  
	
});
</script>




                                
                            </div>	</div>



<div class="row" style="margin:8px;">	
<div class="col-md-4"></div>						
	<div class="col-md-4" style="margin: 10px;padding-left: 5px;padding-right: 5px;">
                                     <form id="photo-details" method="post">
                                      <div class='form-group'>
                                        <select name ="product_id" class="form-control input-default">
                                        <?php
											include('../../mysqli.php');
											$query1 = "SELECT * FROM izzysales_products";
											$result1 = mysqli_query($mysqli, $query1);

											?>

											<?php foreach($result1 AS $result1):
												echo '<option value="'.$result1['goods_id'].'">'.$result1['goods_name'].'</option>';
											endforeach;

?>
                                    </select>
                                    </div>
									
				
					
				
					        
                                    <div class='form-group'>
                                        <input type="button" class="btn btn-primary btn-block" id="imge-details" value="Save">
                                                
                                    <input type="hidden" name="pht-id"value="<?php echo $photo_id;?>">    
                                    <input type="hidden" name="usr-id"value="<?php echo $usr_id;?>">    
                                    <input type="hidden" name="fl-img-uri"value="<?php echo $ful_img_uri;?>">    
                                  

										
                                        </form>
                                        <p id="form-result"></p>
                                    
                                    
                                    </div>
								
			
				
                               
                            </div>				
					
							<div class="col-md-4"></div>
							<!-- Column left ends-->
							
							<!-- Column right starts-->
							
                           
                            
							<!-- Column right ends-->
							
                        </div>  
                               
         <div class="row">
	
	<div class="col-lg-12">
		
	   <div style="margin-top:15px; margin-bottom:25px">    
       <div id="accordion-two" class="accordion" style="background:#e7ebed">
          <div class="accordion__item">
				<div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapsefour" style="background: #e5e373;border: 1px solid #d6c95d;">
					<span><i class="fa fa-plus" style="padding-right:10px"></i></span><span class="accordion__header--text">VIEW IMAGES</span>
					<span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
				</div>
					<div id="collapsefour" class="collapse accordion__body" data-parent="#accordion-two">
						<div class="accordion__body--text">
           
<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   
	      <select class="form-control input-default" name="image_list" onchange="getImages(this.value)">
	    <?php include('get_products_list.php');?>
	   </select>
	   
	   
	   
	</div>
	<div class="col-lg-8">
	   
	</div>
    </div>   
		   
	
	
	<div id="get_images">

	</div>

</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
	
	</div>      
           
                   </div>    

	</div>





        <!--**********************************
            Content body end
        ***********************************-->

 <!--**********************************
            Footer start
        ***********************************-->
        
		<div class="row">
		<div class="col-lg-12">
		<div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        



<script src="../../vendor/global/global.min.js"></script>
<script src="../../js/custom.min.js"></script>
    </div>
 </div>
</body>

</html>