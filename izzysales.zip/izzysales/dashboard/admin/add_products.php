<?php session_start();
include('session.php'); 
include('../../mysqli.php');

$query1 = "SELECT * FROM izzysales_users WHERE user_id = '$logged_user_id'";
$result1 = mysqli_query($mysqli, $query1);

if (mysqli_num_rows($result1) > 0) {
     while($row = mysqli_fetch_assoc($result1)) {
        $usr_dp_pic= $row["image"];
		$userfullname = $row["fname"];
    }
} else {
    $usr_dp_pic = 'default.png';
}

$query2 = "SELECT * FROM izzysales_settings";
$result2 = mysqli_query($mysqli, $query2);
     while($row = mysqli_fetch_assoc($result2)) {
        $company_name= $row["company_name"];
		
    }
 
$mysqli->close();

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>izzysales ADD PRODUCTS </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ME_URI;?>images/favicon.png">
    <link href="<?php echo ME_URI;?>css/style.css" rel="stylesheet">

</head>


<body>
<?php include('../../nav_header.php');?>

<?php include('sidebar.php');?> 

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="<?php echo ME_URI;?>dist/js/jquery.imgareaselect.min.js" type="text/javascript"></script>	
   		<link rel="stylesheet" href="<?php echo ME_URI;?>dist/css/dropzone.css" />
		<link href="<?php echo ME_URI;?>dist/css/cropper.css" rel="stylesheet"/>
		<script src="<?php echo ME_URI;?>dist/js/dropzone.js"></script>
		<script src="<?php echo ME_URI;?>dist/js/cropper.js"></script>








<script>
function getProduct(str) {
  if (str=="") {
    document.getElementById("goods_name").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("get_details").innerHTML=this.response;
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","get_product_details.php?q="+str,true);
  xmlhttp.send();
}

function getProductVar(str) {
  if (str=="") {
    document.getElementById("goods_name").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("get_details2").innerHTML=this.response;
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","../form/get_product_variants.php?q="+str,true);
  xmlhttp.send();
}

function getImages(str) {
  if (str=="") {
    document.getElementById("images_list").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("get_images").innerHTML=this.response;
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","get_product_images.php?q="+str,true);
  xmlhttp.send();
}

function addImages(str) {
  if (str=="") {
    document.getElementById("add_images").innerHTML="";
    return;
  }
  var xmlhttp=new XMLHttpRequest();
  xmlhttp.onreadystatechange=function() {
    if (this.readyState==4 && this.status==200) {
		
      document.getElementById("add_images").innerHTML=this.response;
      //document.getElementById("supp_name1").value=this.responseText; 
    }
  }
  xmlhttp.open("GET","add_product_images.php?q="+str,true);
  xmlhttp.send();
}

</script>
        <!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
	<div class="container-fluid">
		<div class="row" style="min-height:640px">
			<div class="col-xl-12 col-lg-12 col-md-12">
				
					
				<div class="col-lg-12">
					<div class="row" style="margin-top:10px;">
						<div class="col-lg-7">
						
						</div>
						
						<div class="col-lg-5">
						
						</div>
					</div>        
				
					<!-- Body Content -->
		<div class="row">		
		<div class="col-lg-12">
		<form action="../form/add_product.php" method = "POST">
	   <div style="margin-top:10px; margin-bottom:25px">    
       <div id="accordion-one" class="accordion" style="background:#e7ebed">
                                    <div class="accordion__item">
                                        <div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapseone" style="background: #e5e373;border: 1px solid #d6c95d;">
                                            <span><i class="fa fa-plus" style="padding-right:15px"></i></span><span class="accordion__header--text">ADD NEW PRODUCT</span>
                                            <span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
                                        </div>
                                        <div id="collapseone" class="collapse accordion__body" data-parent="#accordion-one">
                                            <div class="accordion__body--text">
                                           
	<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="goods_name" placeholder="PRODUCT NAME" required> 
	</div>
	<div class="col-lg-4">
	   <select class="form-control input-default" name="goods_type">
	   <option value="VARIABLE">VARIABLE</option>
	   <option value="SINGLE">NON VARIABLE</option>
	    </select>
	   
	</div>
	<div class="col-lg-4">
	   <select class="form-control input-default" name="goods_unit">
	   <option value="KGS">KGS</option>
	   <option value="NOS">NOS</option>
	   <option value="LITRES">LITRES</option>
	    <option value="DOZEN">DOZEN</option>
		 <option value="DOZEN">METRES</option>
	    </select>
	</div>
    </div>   

<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="price" placeholder="PRICE"> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="discount" placeholder="DISCOUNT"> 
	</div>
	<div class="col-lg-4">
	    <input type="text" class="form-control input-default" name="rating" placeholder="RATING"> 
	</div>
    </div> 



<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-12">
	   <textarea name="description" rows="4" cols="50" class="form-control input-default" placeholder="DESCRIPTION"> 
	   </textarea>
	</div>
	
    </div> 


	

<button type="submit" class="btn btn-primary">ADD</button>
</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
</div>

</div>


	
				<div class="col-lg-12">
					<div class="row" style="margin-top:10px;">
						<div class="col-lg-7">
						
						</div>
						
						<div class="col-lg-5">
						
						</div>
					</div>        
					
					<!-- Body Content -->
		<div class="row">		
		<div class="col-lg-12">
		
	   <div style="margin-top:15px; margin-bottom:25px">    
       <div id="accordion-two" class="accordion" style="background:#e7ebed">
          <div class="accordion__item">
				<div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapsetwo" style="background: #e5e373;border: 1px solid #d6c95d;">
					<span><i class="fa fa-plus" style="padding-right:10px"></i></span><span class="accordion__header--text">ADD VARIANT</span>
					<span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
				</div>
					<div id="collapsetwo" class="collapse accordion__body" data-parent="#accordion-two">
						<div class="accordion__body--text">
           
<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   
	      <select class="form-control input-default" name="goods_name" onchange="getProduct(this.value)" size="2">
	    <?php include('get_products_list.php');?>
	   </select>
	   
	   
	   
	</div>
	<div class="col-lg-8">
	   
	</div>
    </div>   
		   
	
	
	<div id="get_details">

	</div>

</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
</div>

<div class="row">		
		<div class="col-lg-12">
		
	   <div style="margin-top:15px; margin-bottom:25px">    
       <div id="accordion-two" class="accordion" style="background:#e7ebed">
          <div class="accordion__item">
				<div class="accordion__header collapsed" data-toggle="collapse" data-target="#collapsefour" style="background: #e5e373;border: 1px solid #d6c95d;">
					<span><i class="fa fa-plus" style="padding-right:10px"></i></span><span class="accordion__header--text">VIEW IMAGES</span>
					<span style="position: absolute;right: 1.5625rem;top: 50%;transform: translateY(-50%);"><i class="bi bi-arrow-down"></i></span>
				</div>
					<div id="collapsefour" class="collapse accordion__body" data-parent="#accordion-two">
						<div class="accordion__body--text">
           
<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   
	      <select class="form-control input-default" name="image_list" onchange="getImages(this.value)" size="2">
	    <?php include('get_products_list.php');?>
	   </select>
	   
	   
	   
	</div>
	<div class="col-lg-8">
	   
	</div>
    </div>   
		   
	
	
	<div id="get_images">

	</div>

</form>				
				
</div>				
</div>				
			
				

					<!-- Body Content END -->
					
								
		</div>   
	</div>

</div>
</div>
</div>


<div class="row" style="margin: 15px 0px 0px 0px; background: #e5e373;border: 1px solid #d6c95d;"">		
		<a href="add_images.php" style="border:none"><div class="col-lg-12" style="padding: 0.9375rem; cursor: pointer; position: relative; color: #333;
    font-weight: 500">
		<span><i class="fa fa-plus" style="padding-right:10px"></i></span><span class="accordion__header--text">ADD IMAGES</span>
   

</div></a>
</div>


</div>

</div>
</div>
</div>
</div>
        <!--**********************************
            Content body end
        ***********************************-->

 <!--**********************************
            Footer start
        ***********************************-->
        
		<div class="row">
		<div class="col-lg-12">
		<div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        



<script src="../../vendor/global/global.min.js"></script>
<script src="../../js/custom.min.js"></script>
    </div>
 </div>
 
 
</body>

</html>

