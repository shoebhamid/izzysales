<?php
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_products_details WHERE goods_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     $variant_id = $row['variant_num'];
}

$mysqli->close();
?>

<div class="row" style="margin-bottom:8px; margin-top:10px">	
	
<!-- Datatable -->
       <table class="table table-light table-hover table-sm" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:10px">

            <thead>
                <tr class="table-success">
                   
					           
								<th class="" data-column="be_out_hr_mod">BRAND</th>
								<th class="" data-column="be_out_hr_mod">HSN</th>
								<th class="" data-column="be_out_hr_mod">COLOR</th>
								<th class="" data-column="be_out_hr_mod">SIZE</th>
								 <th class="" data-column="be_out_hr_mod">VARIANT</th>
								<th class="" data-column="be_out_hr_mod">WEIGHT</th>
								<th class="" data-column="be_out_hr_mod">LENGTH</th>
								<th class="" data-column="be_out_hr_mod">BREADTH</th>
								<th class="" data-column="be_out_hr_mod">HEIGHT</th>
								<th class="" data-column="be_out_hr_mod">model</th>
								<th class="" data-column="be_out_hr_mod">PRICE</th>
								<th class="" data-column="be_out_hr_mod">DISCOUNT</th>
								<th class="" data-column="be_out_hr_mod">STOCK</th>
								
                </tr>
            </thead>
            <tbody>
		
                <?php foreach($result as $result): ?>
					
				<?php $sr_num = $result['variant_num'];?>
				
                <tr>
                   
					
					<td><input type="text" style="font-size:11px" class="form-control input-default" name="brand_var_<?php echo $sr_num;?>" value="<?php echo $result['brand'];?>"></td>
					
					
					<td><input type="text" style="font-size:11px" class="form-control input-default" name="hsn_var_<?php echo $sr_num;?>" value="<?php echo $result['hsn_code'];?>"></td>
                   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="color_var_<?php echo $sr_num;?>" value="<?php echo $result['color'];?>"></td>
				   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="size_var_<?php echo $sr_num;?>" value="<?php echo $result['size'];?>"></td>
				   
				    <td><input type="number" style="font-size:11px" class="form-control input-default" name="var_serial" value="<?php echo $sr_num;?>" readonly></td> 
					
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="weight_var_<?php echo $sr_num;?>" value="<?php echo $result['weight'];?>"></td>
				   
                <td><input type="text" style="font-size:11px" class="form-control input-default" name="length_var_<?php echo $sr_num;?>" value="<?php echo $result['length'];?>"></td>
				
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="breadth_var_<?php echo $sr_num;?>" value="<?php echo $result['breadth'];?>"></td>
				
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="height_var_<?php echo $sr_num;?>" value="<?php echo $result['height'];?>"></td>
				
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="model_var_<?php echo $sr_num;?>" value="<?php echo $result['model'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="price_var_<?php echo $sr_num;?>" value="<?php echo $result['price'];?>"></td>
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="discount_price_var_<?php echo $sr_num;?>" value="<?php echo $result['discount_price'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="stock_var_<?php echo $sr_num;?>" value="<?php echo $result['stock'];?>"></td>
				</tr>
												
                <?php endforeach; ?>
		        <input type="hidden" name="total_records" value="<?php echo $total_records;?>">
				<input type="hidden" name="goods_id" value="<?php echo $q;?>">
				
				</tbody>
        </table>
                 
				 
</div>   

