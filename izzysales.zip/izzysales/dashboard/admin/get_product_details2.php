<?php
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_products_details WHERE goods_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     $variant_id = $row['variant_num'];
	 
}

$query2 = "SELECT * FROM izzysales_products WHERE goods_id ='$q'";
$result2 = mysqli_query($mysqli, $query2);
while($row = mysqli_fetch_array($result2)) {
     $goods_name = $row['goods_name'];
	 $goods_description = $row['goods_name'];
	  //$min_sku = $row['min_stock'];
	  
}



$mysqli->close();
?>



<div class="row" style="margin-bottom:8px; margin-top:8px" id="supp_name">
<div class="col-lg-3" style="padding: 0px 3px 0px 15px !Important;">
	   <input type="text" class="form-control input-default" name="prod_name" placeholder="PROD NAME" value="<?php echo $goods_name;?>" readonly> 
	</div>
	<div class="col-lg-5" style="padding: 0px 3px !Important;">
	   <input type="text" class="form-control input-default" name="prod_desc" placeholder="PROD DESC" value="<?php echo $goods_description;?>"  readonly> 
	</div>
	
	<input type="hidden" name="prod_id" value="<?php echo $q;?>">
	<div class="col-lg-2">
	   <button type="submit" class="btn btn-primary">DELETE</button>
	</div>
	
	</form>	
    </div>   
<span style=" color: red; font-size: 14px; ">*Note: Deleting a product will delete all its Variants, Sale and Orders data</span>
	
 