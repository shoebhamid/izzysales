<?php session_start();

$product_id = $_POST["product_id"];
$photoid = $_POST["pht-id"];
$userid = $_POST["usr-id"];
$fulimgid = $_POST["fl-img-uri"];   

$photo_exists = '../content/product_images/'.$fulimgid;
if (file_exists($photo_exists)){

include('../../mysqli.php');
$sql1 = "SELECT * FROM izzysales_products_images WHERE product_id = '$product_id'";
            $result2 = mysqli_query ($mysqli, $sql1);
	        $rowcnt=$result2->num_rows;
	        if($rowcnt>0){
		while($row = $result2->fetch_assoc()) {
			$sr_num = $row['sr_num'];
			$sr_num_new = $sr_num + 1;
		} 
		} else {
			$sr_num_new = 1;
		}		
$sql2 = "INSERT INTO izzysales_products_images (`image_id`, `product_id`, `user_id`, `sr_num`, `img_uri`) VALUES ('".$photoid."', '".$product_id."', '".$userid."', '".$sr_num_new."', '".$fulimgid."')";
				if ($mysqli->query($sql2) === TRUE) {
				
				$_SESSION['pict_id'] = $photoid;
                               echo '<h4 style="font-size: 11px; font-weight:300; padding-top:15px">';
                               echo "Image uploaded";
                               unset($_SESSION['proceed']);
                               unset($_SESSION['shownot']);
                               $url="add_images.php";
				    	   echo '<script type="text/javascript">';
				           echo 'window.location.href="'.$url.'";';
				           echo '</script>';
				           echo '<noscript>';
				           echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
				           echo '</noscript>';
                                echo "</h4>";
							   
                               } else {
                                       echo "Error: " . $sql2 . "<br>" . $mysqli->error;
                                      }

$mysqli->close();
$_SESSION['phot_id'] = $photoid;
}
else {
	echo '<script language="javascript">';
	echo 'alert("Error: Image not selected")';
	echo '</script>';
}
?>