<?php
include('../mysqli.php');
include('../config.php');

 try {
        $connection = new PDO("mysql:host=$hostname;dbname=$dbName", $username, $password);
        // set the PDO error mode to exception
        $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch(PDOException $e) {
        echo "Database connection failed: " . $e->getMessage();
    }
  
  $limit = isset($_GET['records-limit']) ? $_GET['records-limit'] : 10;
  $page = (isset($_GET['page']) && is_numeric($_GET['page']) ) ? $_GET['page'] : 1;
  $paginationStart = ($page - 1) * $limit;






include('func/date.inc.php');  
  
$sqlsum = "SELECT SUM(`bill_amount`) AS total_sum FROM izzysales_orders WHERE `order_status` = '1' && `date` BETWEEN '$start_date' AND '$end_date'"; 
  $res_sum = $connection->query("$sqlsum")->fetchAll();
  $tot_amt =  $res_sum[0]['total_sum'];
  
$sql2 = "SELECT * FROM `izzysales_orders` WHERE `date` BETWEEN '$start_date' AND '$end_date'"; 
$result=mysqli_query($mysqli,$sql2);  
$tot_customers =  mysqli_num_rows($result);

  
$sql3 = "SELECT * FROM `izzysales_purchase_orders` WHERE `date` BETWEEN '$start_date' AND '$end_date'"; 
$result3=mysqli_query($mysqli,$sql3);  
$tot_purchases =  mysqli_num_rows($result3);

$sql4 = "SELECT * FROM `izzysales_orders` WHERE order_status = '0' && `date` BETWEEN '$start_date' AND '$end_date'"; 
$result4=mysqli_query($mysqli,$sql4);  
$tot_pending_orders =  mysqli_num_rows($result4);

$mysqli->close();
?>

<style>
.card {
	border:none;
}
.stat-widget-one {
	text-align:center;
}


</style>

<div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-icon dib"><i class="fa fa-usd"></i></div>
                                        <div class="stat-content dib" style="margin-left:0px">
                                            <div class="stat-text">Current Month's Sale</div>
                                            <div class="stat-digit"><?php echo $tot_amt;?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
<div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-icon dib"><i class="fa fa-list"></i></div>
                                        <div class="stat-content dib" style="margin-left:0px">
                                            <div class="stat-text">Pending Orders</div>
                                            <div class="stat-digit"><?php echo $tot_pending_orders;?> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                 <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-icon dib"><i class="fa fa-users"></i></div>
                                        <div class="stat-content dib" style="margin-left:0px">
                                            <div class="stat-text">New Customers</div>
                                            <div class="stat-digit"><?php echo $tot_customers;?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3">
                                <div class="card">
                                    <div class="stat-widget-one">
                                        <div class="stat-icon dib"><i class="fa fa-plus-square"></i></div>
                                        <div class="stat-content dib" style="margin-left:0px">
                                            <div class="stat-text">New Purchases</div>
                                            <div class="stat-digit"><?php echo $tot_purchases;?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
						