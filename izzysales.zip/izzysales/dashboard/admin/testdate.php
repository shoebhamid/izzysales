<?php
date_default_timezone_set("Asia/Kolkata");
$date1 = date("Y-m-d H:i:s");
$year = substr($date1,0,4);
echo $year."-03-31 00:00:00";

 

die();

$day = '01';
$time = '00:00:00';
$time2 = '23:00:00';

$start_date = $year.'-'.$month.'-'.$day.' '.$time;
//echo $end_date;

?>