<?php if(!session_start()) {
session_start();
 if (!isset($_SESSION["user_name"])) {
	 header("location:../../login.php");
	 die;
 } 
 
 if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] == "admin") {
	 global $logged_user_name;
	 global $logged_user_id;
	 global $logged_user_fname;
	 global $logged_user_lname;
	 global $logged_user_img;
	 global $logged_user_role;
	 
	 $logged_user_role = $_SESSION["user_role"];
	 $logged_user_name = $_SESSION["user_name"];
	 $logged_user_id = $_SESSION["user_id"];
	 $logged_user_fname = $_SESSION["user_fname"];
	 $logged_user_lname = $_SESSION["user_lname"];
	 $logged_user_img = $_SESSION["user_img"];
	 
	 
 } else {
	 header("location:../../login.php");
	 die;
 }	
}

$q = $_GET['q'];

include('../../mysqli.php');
	
$sql="SELECT * FROM izzysales_products_images WHERE product_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     
}
$mysqli->close();

?>

<form method="GET" action="edit_product_variant.php">
<div class="row" style="margin-bottom:8px; margin-top:30px">	
	
	</div>   
<!-- Datatable -->
       	<div class="row">
                <?php foreach($result as $result): ?>
				<div class="col-lg-2" style="margin-bottom: 15px;">
                <img src="../content/product_images/<?php echo $result['img_uri']; ?>" style="width:100px"> 				
						             
				</div>								
                <?php endforeach; ?>
		        
		 
</div>   

</form>	

