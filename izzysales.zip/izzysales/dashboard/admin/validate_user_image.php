<?php session_start();
include('../../mysqli.php');

$photoid = $_POST["pht-id"];
$userid = $_POST["usr-id"];
$fulimgid = $_POST["fl-img-uri"];   

$photo_exists = '../user/user_pic/'.$fulimgid;
if (file_exists($photo_exists)){


$sql2 = "UPDATE izzysales_users SET image ='$fulimgid' WHERE user_id = '$userid'";
				if ($mysqli->query($sql2) === TRUE) {
				
				$_SESSION['pict_id'] = $photoid;
                               echo '<h4 style="font-size: 11px; font-weight:300; padding-top:15px">';
                               echo "User image updated";
                               unset($_SESSION['proceed']);
                               unset($_SESSION['shownot']);
                               $url="profile.php";
				    	   echo '<script type="text/javascript">';
				           echo 'window.location.href="'.$url.'";';
				           echo '</script>';
				           echo '<noscript>';
				           echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
				           echo '</noscript>';
                                echo "</h4>";
							   
                               } else {
                                       echo "Error: " . $sql2 . "<br>" . $mysqli->error;
                                      }

$mysqli->close();
$_SESSION['phot_id'] = $photoid;
}
else {
	echo '<script language="javascript">';
	echo 'alert("Error: Image not selected")';
	echo '</script>';
}
?>