<?php
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_suppliers WHERE supplier_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
while($row = mysqli_fetch_array($result)) {
  $contact_person = $row['supplier_contact'];
  $supplier_name = $row['supplier_name'];
  $supplier_phone = $row['supplier_phone'];
  $supplier_address = $row['supplier_address'];
  $supplier_gst = $row['supplier_gst'];
   $supplier_credit = $row['supplier_credit'];
    $supplier_debit = $row['supplier_debit'];
	$supplier_id = $row['supplier_id'];
  
}
$mysqli->close();
?>
<div class="row" style="margin-bottom:8px" id="supp_name">
<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="supplier_name" value="<?php echo $supplier_name;?>"> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="person_name" value="<?php echo $contact_person;?>"> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="contact_num" value="<?php echo $supplier_phone;?>"> 
	</div>
    </div>   


<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="address" value="<?php echo $supplier_address;?>">
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="gst" value="<?php echo $supplier_gst;?>">
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="credit" value="<?php echo $supplier_credit;?>">
	</div>
	
</div>   

<div class="row" style="margin-bottom:8px">
<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="debit" value="<?php echo $supplier_debit;?>">
	</div>
<div class="col-lg-4">
	   <button type="submit" class="btn btn-primary">SAVE</button>
	</div>
	<input type="hidden" name="supplier_id" value="<?php echo $supplier_id;?>">
<div class="col-lg-4">
	   
	</div>	
</div>   
</form>