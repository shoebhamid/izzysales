<?php

$q = filter_var($_GET["q"], FILTER_VALIDATE_INT, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);

include('../../mysqli.php');
$sql = "SELECT DISTINCT(order_id), date, bill_amount FROM izzysales_orders WHERE customer_id='$q' LIMIT 10";
$result = mysqli_query($mysqli, $sql);
?>

<table class="table table-light table-striped table-hover" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:14px">

            <thead>
                <tr class="table-success">
                   
					            <th class="" data-column="be_out_hr_mod">ORDER ID</th>
								<th class="" data-column="be_out_hr_mod">DATE</th>
								<th class="" data-column="be_out_hr_mod">BILL</th>
								
								
                </tr>
            </thead>
            <tbody>
			
                <?php foreach($result as $result): ?>
				
							
				
                <tr>
                    
					<td><a href="order_details.php?order_id=<?php echo $result['order_id']; ?>"><?php echo $result['order_id']; ?></a></td>
					<td><?php echo $result['date']; ?></td>
                    <td><?php echo $result['bill_amount']; ?></td>
                    
					
					
                </tr>
							
                <?php endforeach;?>
				
				</tbody>
        </table>

