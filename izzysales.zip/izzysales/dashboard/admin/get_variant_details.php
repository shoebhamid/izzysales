<?php
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_products_details WHERE goods_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
$total_records = $result->num_rows;
while($row = mysqli_fetch_array($result)) {
     $variant_id = $row['variant_num'];
}

$mysqli->close();
?>

<form method="POST" action="../form/delete_product_variant.php">
<div class="row" style="margin-bottom:8px; margin-top:30px">	
	<span style="margin-left:10px"><i class="fa fa-check" style="padding-right:15px"></i></span><span class="accordion__header--text" style="margin-bottom:5px">ALL VARIANTS</span>
<!-- Datatable -->
       <table class="table table-light table-hover table-sm" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:10px">

            <thead>
                <tr class="table-success">
                   
					            <th class="" data-column="be_out_hr_mod">V.No</th>
								<th class="" data-column="be_out_hr_mod">BRAND</th>
								<th class="" data-column="be_out_hr_mod">COLOR</th>
								<th class="" data-column="be_out_hr_mod">SIZE</th>
								<th class="" data-column="be_out_hr_mod">Model</th>
								<th class="" data-column="be_out_hr_mod">PRICE</th>
								<th class="" data-column="be_out_hr_mod">DISCOUNT</th>
								<th class="" data-column="be_out_hr_mod">STOCK</th>
								<th class="" data-column="be_out_hr_mod"></th>
								
								
                </tr>
            </thead>
            <tbody>
		
                <?php foreach($result as $result): ?>
					
				<?php $sr_num = $result['variant_num'];?>
				
                <tr>
                    <td><input type="number" style="font-size:11px" class="form-control input-default" name="var_serial" value="<?php echo $sr_num;?>" readonly></td>
					
					<td><input type="text" style="font-size:11px" class="form-control input-default" name="brand_var_<?php echo $sr_num;?>" value="<?php echo $result['brand'];?>"></td>
					
					
					
                   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="color_var_<?php echo $sr_num;?>" value="<?php echo $result['color'];?>"></td>
				   
				   <td><input type="text" style="font-size:11px" class="form-control input-default" name="size_var_<?php echo $sr_num;?>" value="<?php echo $result['size'];?>"></td>
				   
				  
				<td><input type="text" style="font-size:11px" class="form-control input-default" name="model_var_<?php echo $sr_num;?>" value="<?php echo $result['model'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="price_var_<?php echo $sr_num;?>" value="<?php echo $result['price'];?>"></td>
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="discount_price_var_<?php echo $sr_num;?>" value="<?php echo $result['discount_price'];?>"></td>
				
				<td><input type="number" style="font-size:11px" class="form-control input-default" name="stock_var_<?php echo $sr_num;?>" value="<?php echo $result['stock'];?>"></td>
				
				<td><input type="submit" style="font-size:11px" class="btn-primary form-control input-default" value="DEL"></td>
				
				</tr>
				<input type="hidden" name="goods_id" value="<?php echo $q;?>">
				<input type="hidden" name="var_id" value="<?php echo $variant_id;?>">
				</form>
                <?php endforeach; ?>
		        
				
				
				</tbody>
        </table>
                 
				