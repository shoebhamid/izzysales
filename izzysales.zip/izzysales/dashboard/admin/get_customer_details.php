<?php
include('../../mysqli.php');
$q = $mysqli -> real_escape_string($_GET['q']);

$sql="SELECT * FROM izzysales_customers WHERE customer_id = '".$q."'";
$result = mysqli_query($mysqli, $sql);
while($row = $result->fetch_assoc()) {
  $customer_name = $row['customer_name'];
  $customer_phone = $row['customer_phone'];
  $customer_email = $row['customer_email'];
  $customer_address = $row['customer_address'];
  $customer_id = $row['customer_id'];
 
  
}

$mysqli->close();
?>
<div class="row" style="margin-bottom:8px" id="supp_name">
<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="customer_name" value="<?php echo $customer_name;?>" placeholder="NAME"> 
	</div>
	<div class="col-lg-4">
	   <input type="number" class="form-control input-default" name="customer_phone" value="<?php echo $customer_phone;?>" placeholder="PHONE"> 
	</div>
	<div class="col-lg-4">
	   <input type="text" class="form-control input-default" name="customer_email" value="<?php echo $customer_email;?>" placeholder="EMAIL"> 
	</div>
    </div>   


<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-6">
	   <input type="text" class="form-control input-default" name="customer_address" value="<?php echo $customer_address;?>" placeholder="ADDRESS">
	</div>
	<input type="hidden" name="customer_id" value="<?php echo $customer_id;?>">
	
	<div class="col-lg-2">
	   <button type="submit" class="btn btn-primary">SAVE</button>
	</div>
	<div class="col-lg-4">
	   
	</div>
	
	
</div>   


