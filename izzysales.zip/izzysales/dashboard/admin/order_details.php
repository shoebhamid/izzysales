<?php session_start();
include('session.php'); 
include('../../mysqli.php');

$query1 = "SELECT * FROM izzysales_users WHERE user_id = '$logged_user_id'";
$result1 = mysqli_query($mysqli, $query1);

if (mysqli_num_rows($result1) > 0) {
     while($row = mysqli_fetch_assoc($result1)) {
        $usr_dp_pic= $row["image"];
		$userfullname = $row["fname"];
    }
} else {
    $usr_dp_pic = 'default.png';
}

$query2 = "SELECT * FROM izzysales_settings";
$result2 = mysqli_query($mysqli, $query2);
     while($row = mysqli_fetch_assoc($result2)) {
        $company_name= $row["company_name"];
		
    }
	
$mysqli->close();
 
 if (isset($_GET['order_id']))
 {
	 $order_id = $_GET['order_id'];
 } else {
	 echo "Error: Please search valid Order Id";
	 die();
 }
 
 


include('../func/pdo.inc.php');
  
  // MySQL Query
  $sqlquery = "SELECT * FROM `izzysales_orders`  WHERE order_id = '$order_id' ORDER BY `id` DESC LIMIT $paginationStart, $limit";
  //echo $sqlquery;
 
 
  $sqlquery3 = "SELECT SUM(bill_amount) AS total_amt FROM `izzysales_orders`  WHERE order_id = '$order_id'"; 
   
 // Fetch Rows 
  $entries = $connection->query("$sqlquery")->fetchAll();
  

  $sql3 = $connection->query("$sqlquery3")->fetchAll();
   $total_amount = $sql3[0]['total_amt'];
   

  
	
  
  

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>izzysales ORDER DETAILS </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ME_URI;?>images/favicon.png">
    <link href="<?php echo ME_URI;?>css/style.css" rel="stylesheet">

</head>




<body>
<?php include('../../nav_header.php');?>

<?php include('sidebar.php');?> 

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12">
				
					
			<div class="col-lg-12">
        <div class="row" style="margin-top:10px;">
		<div class="col-lg-7">
		<h4 style="margin:10px 0px 10px 10px; padding:5px; font-size:18px"><span><i class="fa fa-shopping-cart" aria-hidden="true"></i></span> ORDER DETAILS</h4>
		</div>
		<div class="col-lg-5">
		
		</div>
		</div>
		
		<div class="row" style="margin-bottom:5px">
		 
		
		<div class="col-lg-3"><span>ORDER ID</span> <span><strong><?php echo $entries[0]['order_id'];?></strong></span>		
		</div>
		
		<div class="col-lg-3"><span>CUSTOMER ID</span> <span><strong><?php echo $entries[0]['customer_id'];?></strong></span> 
		</div>
		
		<div class="col-lg-3"><span>DATE</span> <span><strong><?php echo $entries[0]['date'];?></strong></span> 
		</div>
		
		
		</div>
        <!-- Datatable -->
       <table class="table table-light table-hover table-sm" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:14px">

            <thead>
                <tr class="table-success">
                                <th class="" data-column="be_out_hr_mod">SR.NO</th>
					            <th class="" data-column="be_out_hr_mod">PRODUCT NAME</th>
								 <th class="" data-column="be_out_hr_mod">VARIANT</th>
								<th class="" data-column="be_out_hr_mod">QUANTITY</th>
								<th class="" data-column="be_out_hr_mod">PRICE</th>
								<th class="" data-column="be_out_hr_mod">BILL AMT</th>
								
								
                </tr>
            </thead>
            <tbody>
			   <?php $ser_num=1;?>
                <?php foreach($entries as $entries): ?>
				<?php if ($entries['order_status'] == '0'){
					$entries['order_status'] = "IN PROCESS";
				} elseif ($entries['order_status'] == '1'){
					$entries['order_status'] = "COMPLETED";
				} 
				
				/* $order_id = $entries['order_id'];
					$col_num = substr($order_id, -1);
					if ($col_num == 1 || $col_num == 3 || $col_num == 5 || $col_num == 7 || $col_num == 9){
						$col_color = "#fff";
					} else {
						$col_color = "#fff";
					}  */
				
				?>
				
				
				
				
				
				
                <tr>
                     <td><?php echo $ser_num.'.'; ?></td>
                    <td><?php echo $entries['product_name']; ?></td>
					<td><?php echo $entries['variant']; ?></td>
					<td><?php echo $entries['quantity']; ?></td>
					<td><?php echo $entries['bill_amount']/$entries['quantity']; ?></td>
					<td><?php echo $entries['bill_amount']; ?></td>
					
					
					
                </tr>
				<?php $ser_num ++;?>			
                <?php endforeach; ?>
				<tr>
				
				<td><strong>Total Amount</strong></td>
				<td></td>
				<td></td>
				<td></td>
				<td></td>
				<td><strong><?php echo $total_amount;?></strong></td>
				
				</tr>
				</tbody>
        </table>
        <!-- Pagination -->
        

 

		
		</div>
		</div>			
									
			</div>   
		</div>
					
					

	</div>

        <!--**********************************
            Content body end
        ***********************************-->

 <!--**********************************
            Footer start
        ***********************************-->
        
		<div class="row">
		<div class="col-lg-12">
		<div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        



<script src="../../vendor/global/global.min.js"></script>
<script src="../../js/custom.min.js"></script>
    </div>
 </div>
</body>

</html>