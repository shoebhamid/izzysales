<?php session_start();
include('session.php'); 
include('../../mysqli.php');

$query1 = "SELECT * FROM izzysales_users WHERE user_id = '$logged_user_id'";
$result1 = mysqli_query($mysqli, $query1);

if (mysqli_num_rows($result1) > 0) {
     while($row = mysqli_fetch_assoc($result1)) {
        $usr_dp_pic= $row["image"];
		$userfullname = $row["fname"];
    }
} else {
    $usr_dp_pic = 'default.png';
}

$query2 = "SELECT * FROM izzysales_settings";
$result2 = mysqli_query($mysqli, $query2);
     while($row = mysqli_fetch_assoc($result2)) {
        $company_name= $row["company_name"];
		
    }
 
$mysqli->close();

include('../func/pdo.inc.php');
include('../func/date.inc.php');  
  // MySQL Query
  $sqlquery = "SELECT * FROM `izzysales_reminders` WHERE user_id = '$logged_user_id' ORDER BY `id` DESC LIMIT $paginationStart, $limit";
  //echo $sqlquery;
  $sqlquery2 = "SELECT count(DISTINCT id) AS id FROM `izzysales_reminders` WHERE user_id = '$logged_user_id'";
 
 // Fetch Rows 
  $entries = $connection->query("$sqlquery")->fetchAll();

  // Get total records
    $sql = $connection->query("$sqlquery2")->fetchAll();
	$allRecrods = $sql[0]['id'];
  
  // Calculate total pages
  $totoalPages = ceil($allRecrods / $limit);
  // Prev + Next
  $prev = $page - 1;
  $next = $page + 1;

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>izzysales GOODS </title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo ME_URI;?>images/favicon.png">
    <link href="<?php echo ME_URI;?>css/style.css" rel="stylesheet">

</head>




<body>
<?php include('../../nav_header.php');?>

<?php include('sidebar.php');?> 

<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

        <!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
	<div class="container-fluid">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12">
				
					
			<div class="col-lg-12">
    

<div class="row" style="margin-top:10px;">
		<div class="col-lg-7">
		<h4 style="margin:10px 0px 10px 10px; padding:5px; font-size:18px"><span><i class="fa fa-bell" aria-hidden="true"></i> </span>REMINDERS</h4>
		</div>
		<div class="col-lg-5">
		<div class="d-flex flex-row-reverse bd-highlight mb-3" style="padding-bottom: 5px;">
            <form action="reminders.php" method="GET">
                <select name="records-limit" id="records-limit" class="custom-select">
                    <option disabled selected>Records Limit</option>
                    <?php foreach([10, 20, 50, 100] as $limit) : ?>
                    <option
                        <?php if(isset($_SESSION['records-limit']) && $_SESSION['records-limit'] == $limit) echo 'selected'; ?>
                        value="<?= $limit; ?>">
                        <?= $limit; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </form>
        </div>
		</div>
		</div>
        <!-- Datatable -->
       <table class="table table-light table-striped table-hover" data-uniqueid="1290731429" style="background: #ededed; max-width:1200px; font-size:14px">

            <thead>
                <tr class="table-success">
                   
					           	<th class="" data-column="be_out_hr_mod">MESSAGE</th>
								<th class="" data-column="be_out_hr_mod">DATE</th>
								<th class="" data-column="be_out_hr_mod"></th>
								
                </tr>
            </thead>
            <tbody>
			<form method="POST" action="../form/delete_reminder.php">
				<?php foreach($entries as $entries):?> 
					 <tr>
                    <td><?php echo $entries['reminder_message']; ?></td>
					<td><?php echo $entries['date']; ?></td>
                   	<td><button class="btn btn-primary" type="submit">DELETE</button></td>
				<input type="hidden" name="reminder_id" value="<?php echo $entries['id'];?>">
					
					
                </tr>			
                						
                <?php endforeach;?> 
				</form>
        </table>
        <!-- Pagination -->
        <nav aria-label="Page navigation example mt-5">
            <ul class="pagination">
                <li class="page-item <?php if($page <= 1){ echo 'disabled'; } ?>">
                    <a class="page-link"
                        href="<?php if($page <= 1){ echo '#'; } else { echo "?page=" . $prev; } ?>">Previous</a>
                </li>
                <?php for($i = 1; $i <= $totoalPages; $i++ ): ?>
                <li class="page-item <?php if($page == $i) {echo 'active'; } ?>">
                    <a class="page-link" href="reminders.php?page=<?= $i; ?>"> <?= $i; ?> </a>
                </li>
                <?php endfor; ?>
                <li class="page-item <?php if($page >= $totoalPages) { echo 'disabled'; } ?>">
                    <a class="page-link"
                        href="<?php if($page >= $totoalPages){ echo '#'; } else {echo "?page=". $next; } ?>">Next</a>
                </li>
            </ul>
        </nav>

    <!-- jQuery + Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#records-limit').change(function () {
                $('form').submit();
            })
        });
    </script>




















		
		</div>
		</div>			
									
			</div>   
		</div>
					
					

	</div>





        <!--**********************************
            Content body end
        ***********************************-->

 <!--**********************************
            Footer start
        ***********************************-->
        
		<div class="row">
		<div class="col-lg-12">
		<div class="footer">
            <div class="copyright">
                <p>Supported by <a href="#" target="_blank">IZZY SALES</a> 2024</p>
            </div>
        </div>
        



<script src="../../vendor/global/global.min.js"></script>
<script src="../../js/custom.min.js"></script>
    </div>
 </div>
</body>

</html>