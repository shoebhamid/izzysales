<?php
include('../../mysqli.php');
$user_id = $mysqli -> real_escape_string($_POST['user_id']);
$f_name = $mysqli -> real_escape_string($_POST['f_name']);
$l_name = $mysqli -> real_escape_string($_POST['l_name']);
$username = $mysqli -> real_escape_string($_POST['username']);
$password = $mysqli -> real_escape_string($_POST['password']);
$phone = $mysqli -> real_escape_string($_POST['phone']);
$email = $mysqli -> real_escape_string($_POST['email']);
$role = $mysqli -> real_escape_string($_POST['role']);
$status = $mysqli -> real_escape_string($_POST['status']);


if(!isset($user_id)) {
	echo 'Please select valid user id';
	die();
}


$sql="UPDATE izzysales_users SET fname='$f_name', lname='$l_name', username='$username', password='$password', role='$role', status = '$status', email = '$email', phone = '$phone' WHERE user_id = '$user_id'";


if (mysqli_query($mysqli,$sql)){
echo '<script>';
echo 'alert("Changes saved")'; 
echo '</script>';
$url="add_user.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
} else {
	echo "Error in saving changes";
}















?>