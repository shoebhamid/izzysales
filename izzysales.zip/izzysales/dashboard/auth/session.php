<?php if (!isset($_SESSION["user_name"])) {
	 header("location:../../login.php");
	 die;
 } 
 if (isset($_SESSION["user_role"]) && $_SESSION["user_role"] == "auth") {
	 global $logged_user_name;
	 global $logged_user_id;
	 global $logged_user_fname;
	 global $logged_user_lname;
	 global $logged_user_img;
	 global $logged_user_role;
	 $logged_user_role = $_SESSION["user_role"];
	 $logged_user_name = $_SESSION["user_name"];
	 $logged_user_id = $_SESSION["user_id"];
	 $logged_user_fname = $_SESSION["user_fname"];
	 $logged_user_lname = $_SESSION["user_lname"];
	 $logged_user_img = $_SESSION["user_img"];
	 
 } else {
	 header("location:../../login.php");
	 die;
 }
 
define('useraccess', TRUE);
?>