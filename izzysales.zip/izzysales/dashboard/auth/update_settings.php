<?php
include('../../mysqli.php');
$company_name = $mysqli -> real_escape_string($_POST['company_name']);
$address = $mysqli -> real_escape_string($_POST['address']);

if(!isset($company_name)) {
	echo 'Please select valid user id';
	die();
}


$sql="UPDATE izzysales_settings SET company_name='$company_name', address='$address'";

if (mysqli_query($mysqli,$sql)){
echo '<script>';
echo 'alert("Changes saved")'; 
echo '</script>';
$url="settings.php";
echo '<script type="text/javascript">';
echo 'window.location.href="'.$url.'";';
echo '</script>';
echo '<noscript>';
echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
echo '</noscript>';	
} else {
	echo "Error in saving changes";
}















?>