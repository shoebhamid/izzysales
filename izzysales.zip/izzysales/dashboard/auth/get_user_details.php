<?php
$q = $_GET['q'];

include('../../mysqli.php');
$sql="SELECT * FROM izzysales_users WHERE user_id = '".$q."'";
$result = mysqli_query($mysqli,$sql);
while($row = mysqli_fetch_array($result)) {
  $fname = $row['fname'];
  $lname = $row['lname'];
  $username = $row['username'];
  $password = $row['password'];
  $email = $row['email'];
   $phone = $row['phone'];
    $role = $row['role'];
	$status = $row['status'];
  
}
$mysqli->close();
?>
 <div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="f_name" placeholder="USER FIRST NAME" value="<?php echo $fname ;?>"> 
	</div>
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="l_name" placeholder="USER LAST NAME" value="<?php echo $lname ;?>"> 
	</div>
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="username" placeholder="USERNAME" value="<?php echo $username ;?>"> 
	</div>
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="password" placeholder="PASSWORD" value="<?php echo $password ;?>"> 
	</div>
    </div>   

<div class="row" style="margin-bottom:8px">
	
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="phone" placeholder="PHONE" value="<?php echo $phone ;?>"> 
	</div>
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="email" placeholder="EMAIL" value="<?php echo $email ;?>"> 
	</div>
	
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="role" placeholder="ROLE" value="<?php echo $role ;?>"> 
	</div>	
	<div class="col-lg-3">
	   <input type="text" class="form-control input-default" name="status" placeholder="STATUS" value="<?php echo $status ;?>"> 
	</div>
    </div>   
	
<div class="row" style="margin-bottom:8px">	
	
	
<div class="col-lg-4">
	   <button type="submit" class="btn btn-primary">SAVE</button>
	</div>
	<input type="hidden" name="user_id" value="<?php echo $q ;?>">
	<div class="col-lg-4">
	  
	</div>
</div>
			
</form>				