        <!--**********************************
            Sidebar start
        ***********************************-->
        <div class="behrmsnav">
            <div class="behrmsnav-scroll">
                <ul class="metismenu" id="menu">
                    <?php 
					if ($_SESSION["user_role"] == "auth") {?>
					<li><a class="" href="../auth/" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-cogs" aria-hidden="true"></i></span><span class="nav-text" style="font-weight:500">ADMIN HOME</span></a>
                    </li>
					
					<?php						
					}					
					?>
                    <li><a class="" href="../../dashboard/" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-home" aria-hidden="true"></i></span><span class="nav-text" style="font-weight:500">DASHBOARD</span></a>
                    </li>
                   
				   <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-usd" aria-hidden="true"></i></span><span class="nav-text">SALES</span></a>
                        <ul aria-expanded="false">
						<li><a href="../admin/new_sale.php">ADD/EDIT SALE</a></li>	
                            <li><a href="../admin/recent_sale.php">RECENT SALE</a></li>
							<li><a href="../admin/monthly_sale.php">MONTH'S SALE</a></li>
                            											
                        </ul>
                    </li>  
                      
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-list" aria-hidden="true"></i></span><span class="nav-text">ORDERS</span></a>
                        <ul aria-expanded="false">
						<li><a href="../admin/new_order.php">ADD/PROCESS ORDERS</a></li>	
                            <li><a href="../admin/recent_orders.php">RECENT ORDERS</a></li>
							<li><a href="../admin/monthly_orders.php">MONTHLY ORDERS</a></li>
                            	
							
                        </ul>
                    </li> 
					
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-user" aria-hidden="true"></i></span><span class="nav-text">CUSTOMERS</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../admin/registered_customers.php">CUSTOMERS</a></li>
							<li><a href="../admin/register_customer.php">REGISTER CUSTOMER</a></li>
                            <li><a href="../admin/customers_sale.php">CUSTOMER SALE</a></li>												
                        </ul>
                    </li>  
					
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-product-hunt" aria-hidden="true"></i></span><span class="nav-text">PRODUCTS</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../admin/products.php">VIEW PRODUCTS</a></li>
                            <li><a href="../admin/add_products.php">ADD PRODUCTS</a></li>	
							<li><a>EDIT PRODUCTS</a></li>	
							<li><a href="../admin/delete_products.php">DELETE PRODUCTS</a></li>
					    </ul>
                    </li> 
										 
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-strikethrough" aria-hidden="true"></i></span><span class="nav-text">SUPPLIERS</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../admin/suppliers.php">SUPPLIERS</a></li>
                            <li><a href="../admin/add_supplier.php">ADD SUPPLIER</a></li>
							<li><a href="../admin/suppliers_outstanding.php">OUTSTANDING</a></li>
                        </ul>
                    </li>    
					
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-plus-square" aria-hidden="true"></i></span><span class="nav-text">PURCHASES</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../admin/recent_purchase_orders.php">PURCHASE ORDERS</a></li>
                            <li><a href="../admin/new_po.php">ADD/EDIT PO</a></li>												
                        </ul>
                    </li> 
					
					<li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-archive" aria-hidden="true"></i></span><span class="nav-text">INVENTORY</span></a>
                        <ul aria-expanded="false">
                            <li><a href="../admin/stock.php">STOCK</a></li>
                            <li><a>UPDATE STOCK</a></li>												
                        </ul>
                    </li>    
					
				    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><span style="padding-right:10px"><i class="fa fa-bell" aria-hidden="true"></i></span><span class="nav-text">REMINDERS</span></a>
                        <ul aria-expanded="false">
                           <li><a href="../admin/reminders.php">VIEW REMINDERS</a></li>
                           	<li><a href="../admin/add_reminder.php">ADD REMINDERS</a></li>										
                        </ul>
                    </li>    
            </div>


        </div>
        <!--**********************************
            Sidebar end
        ***********************************-->
