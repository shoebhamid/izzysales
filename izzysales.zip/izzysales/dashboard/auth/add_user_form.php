<?php
include('../../mysqli.php');
$f_name = $mysqli -> real_escape_string($_POST['f_name']);
$l_name = $mysqli -> real_escape_string($_POST['l_name']);
$username = $mysqli -> real_escape_string($_POST['username']);
$password = $mysqli -> real_escape_string($_POST['password']);
$phone = $mysqli -> real_escape_string($_POST['phone']);
$email = $mysqli -> real_escape_string($_POST['email']);
$role = $mysqli -> real_escape_string($_POST['role']);
$status = $mysqli -> real_escape_string($_POST['status']);


include('../func/redirect.inc.php');

if(!isset($f_name)) {
	echo '<script>'.'alert("Please select valid name")'.'</script>';
	redirect_user("../auth/add_user.php");
	die();
}

if(!isset($username)) {
	echo '<script>'.'alert("Please select valid username")'.'</script>';
	redirect_user("../auth/add_user.php");
	die();
}

if (!preg_match('/^[a-zA-Z0-9]{6,15}$/',$username)) {
	echo '<script>'.'alert("Please select valid username: Use alphabets and numbers only, 6 characters min")'.'</script>';
	redirect_user("../auth/add_user.php");
	die();
	
}

if(!isset($password)) {
	echo '<script>'.'alert("Please select valid password")'.'</script>';
	redirect_user("../auth/add_user.php");
	die();
}

if(!isset($role)) {
	echo '<script>'.'alert("Please select valid role")'.'</script>';
	redirect_user("../auth/add_user.php");
	die();
}

if(!isset($status)) {
	echo '<script>'.'alert("Please select valid status")'.'</script>';
	redirect_user("../auth/add_user.php");
	die();
}


$sql1 = "SELECT user_id FROM izzysales_users ORDER BY user_id DESC LIMIT 1";
$result = mysqli_query($mysqli, $sql1);
while($row = $result->fetch_assoc()) {
	$last_user_id = $row['user_id'];
}
$new_user_id = $last_user_id + 1;



$sql2 = "INSERT INTO izzysales_users(`fname`, `lname`, `username`, `password`, `role`, `status`, `email`, `phone`,`user_id`) VALUES('".$f_name."', '".$l_name."', '".$username."', '".$password."', '".$role."', '".$status."', '".$email."', '".$phone."', '".$new_user_id."')";
//echo $sql2 ;
//die();
if (mysqli_query($mysqli, $sql2)) {
echo '<script>'.'alert("User added successfully")'.'</script>';	
redirect_user("../auth/add_user.php");
die();  
}
















?>