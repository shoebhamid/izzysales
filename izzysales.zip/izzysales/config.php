<?php
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected and not available to public.");
}

/* Important details about server and database */
if ( !defined('ME_PATH') )
        define('ME_PATH', dirname(__FILE__) . '/');
        
if ( !defined('ME_URI') )
        define('ME_URI', 'http://localhost/izzysales/');

if ( !defined('DB_SERVER') )
	define('DB_SERVER', 'localhost');

if ( !defined('DB_USERNAME') )
	define('DB_USERNAME', 'shoeb');

if ( !defined('DB_PASSWORD') )
	define('DB_PASSWORD', 'hamid');

if ( !defined('DB_DATABASE') )
	define('DB_DATABASE', 'izzysales_db');

$hostname = DB_SERVER;
$dbName = DB_DATABASE;
$username =  DB_USERNAME;
$password = DB_PASSWORD;