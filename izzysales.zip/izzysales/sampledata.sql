-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 20, 2024 at 06:21 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+05:30";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `izzysales_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_customers`
--

DROP TABLE IF EXISTS `izzysales_customers`;
CREATE TABLE IF NOT EXISTS `izzysales_customers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(12) DEFAULT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `customer_email` varchar(150) DEFAULT NULL,
  `customer_address` varchar(200) DEFAULT NULL,
  `last_order_id` bigint(12) DEFAULT NULL,
  `member_since` datetime DEFAULT CURRENT_TIMESTAMP,
  `membership_status` varchar(50) NOT NULL DEFAULT 'ACTIVE',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_customers`
--

INSERT INTO `izzysales_customers` (`id`, `customer_id`, `customer_name`, `customer_phone`, `customer_email`, `customer_address`, `last_order_id`, `member_since`, `membership_status`) VALUES
(1, 60001, 'Shoeb Hamid', '23213213', 'shoebhamid@gmail.com', 'Rajbagh', 1220220, '2024-04-26 10:33:02', 'ACTIVE'),
(2, 60002, NULL, NULL, NULL, NULL, NULL, '2024-05-03 17:47:35', 'ACTIVE'),
(3, 60003, 'Asif', '23213213', 'asif@test.com', '', NULL, '2024-05-03 17:58:28', 'ACTIVE'),
(4, 60004, '', NULL, NULL, NULL, NULL, '2024-05-03 17:59:26', 'ACTIVE'),
(5, 60005, '', NULL, NULL, NULL, NULL, '2024-05-04 09:25:26', 'ACTIVE'),
(6, 60006, '', NULL, NULL, NULL, NULL, '2024-05-04 09:26:40', 'ACTIVE'),
(8, 60007, '', NULL, NULL, NULL, NULL, '2024-05-04 10:12:04', 'ACTIVE'),
(9, 60008, '', NULL, NULL, NULL, NULL, '2024-05-04 10:13:08', 'ACTIVE'),
(10, 60009, '', NULL, NULL, NULL, NULL, '2024-05-04 10:26:49', 'ACTIVE'),
(19, 60010, '', NULL, NULL, NULL, NULL, '2024-05-14 11:18:27', 'ACTIVE'),
(20, 60011, '', NULL, NULL, NULL, NULL, '2024-05-16 10:50:02', 'ACTIVE'),
(22, 60012, '', NULL, NULL, NULL, NULL, '2024-05-18 23:43:04', 'ACTIVE');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_orders`
--

DROP TABLE IF EXISTS `izzysales_orders`;
CREATE TABLE IF NOT EXISTS `izzysales_orders` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(12) NOT NULL,
  `customer_id` bigint(12) DEFAULT NULL,
  `product_id` bigint(12) DEFAULT NULL,
  `product_name` varchar(200) DEFAULT NULL,
  `variant` int(10) DEFAULT NULL,
  `unit` varchar(30) DEFAULT NULL,
  `quantity` float DEFAULT NULL,
  `bill_amount` float DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `order_status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_orders`
--

INSERT INTO `izzysales_orders` (`id`, `order_id`, `customer_id`, `product_id`, `product_name`, `variant`, `unit`, `quantity`, `bill_amount`, `date`, `order_status`) VALUES
(34, 1220225, 60002, 10010, 'Hauser Pen XO', 2, 'NOS', 5, 60, '2024-05-02 10:57:01', 1),
(53, 1220238, 60011, 10010, 'Hauser Pen XO', 2, 'NOS', 2, 24, '2024-05-16 10:50:02', 1),
(41, 1220230, 60002, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-03 17:47:35', 1),
(35, 1220226, 60002, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-02 10:58:58', 1),
(32, 1220224, 60002, 10010, 'Hauser Pen XO', 1, 'NOS', 4, 40, '2024-04-29 12:46:11', 1),
(30, 1220223, 60002, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 13, '2024-04-29 11:44:43', 1),
(45, 1220234, 60006, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-04 09:26:40', 1),
(46, 1220235, 60003, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-04 09:43:06', 1),
(48, 1220236, 60003, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-04 10:11:24', 1),
(51, 1220237, 60010, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-14 11:18:27', 1),
(52, 1220237, 60010, 10011, 'Reynolds Pen', 1, 'NOS', 1, 12, '2024-05-14 11:18:27', 1),
(54, 1220239, 60012, 10010, 'Hauser Pen XO', 1, 'NOS', 1, 12, '2024-05-18 23:43:04', 1);

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_products`
--

DROP TABLE IF EXISTS `izzysales_products`;
CREATE TABLE IF NOT EXISTS `izzysales_products` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `goods_id` int(10) NOT NULL,
  `goods_name` varchar(200) NOT NULL,
  `goods_type` varchar(100) DEFAULT NULL,
  `goods_unit` varchar(30) DEFAULT NULL,
  `goods_price` float DEFAULT NULL,
  `goods_discount` int(10) NOT NULL,
  `goods_rating` int(11) DEFAULT NULL,
  `goods_description` varchar(300) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_products`
--

INSERT INTO `izzysales_products` (`id`, `goods_id`, `goods_name`, `goods_type`, `goods_unit`, `goods_price`, `goods_discount`, `goods_rating`, `goods_description`, `date`) VALUES
(1, 10010, 'Hauser Pen XO', 'Variable', 'NOS', 10, 0, 5, '2', '2024-04-22 16:16:35'),
(6, 10011, 'Reynolds Pen', 'VARIABLE', 'NOS', 12, 10, 4, ' \r\n	   Fine ball point pen. ', '2024-05-13 16:16:48');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_products_details`
--

DROP TABLE IF EXISTS `izzysales_products_details`;
CREATE TABLE IF NOT EXISTS `izzysales_products_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `goods_id` int(11) NOT NULL,
  `variant_num` int(11) DEFAULT NULL,
  `color` varchar(30) DEFAULT NULL,
  `length` varchar(20) DEFAULT NULL,
  `breadth` varchar(20) DEFAULT NULL,
  `height` varchar(20) DEFAULT NULL,
  `size` varchar(20) DEFAULT NULL,
  `weight` varchar(20) DEFAULT NULL,
  `volume` varchar(100) DEFAULT NULL,
  `brand` varchar(100) DEFAULT NULL,
  `hsn_code` varchar(30) DEFAULT NULL,
  `model` varchar(10) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `discount_price` varchar(30) NOT NULL DEFAULT '0',
  `stock` float DEFAULT NULL,
  `min_sku` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_products_details`
--

INSERT INTO `izzysales_products_details` (`id`, `goods_id`, `variant_num`, `color`, `length`, `breadth`, `height`, `size`, `weight`, `volume`, `brand`, `hsn_code`, `model`, `price`, `discount_price`, `stock`, `min_sku`) VALUES
(1, 10010, 1, 'Red', '20 CM', NULL, NULL, NULL, NULL, NULL, 'HAUSER GERMANY', '87149990', NULL, 12, '20', 21, 1),
(2, 10010, 2, 'Green', '20 CM', '', '', '', '', '', 'HAUSER GERMANY', '87149990', '', 12, '20', 12, 1),
(6, 10011, 1, 'Blue', '', '', '', '', '', '', 'Reynolds', '', '', 12, '10', 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_products_images`
--

DROP TABLE IF EXISTS `izzysales_products_images`;
CREATE TABLE IF NOT EXISTS `izzysales_products_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `image_id` int(11) DEFAULT NULL,
  `product_id` int(10) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `sr_num` int(10) DEFAULT NULL,
  `img_uri` varchar(100) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_products_images`
--

INSERT INTO `izzysales_products_images` (`id`, `image_id`, `product_id`, `user_id`, `sr_num`, `img_uri`, `date`) VALUES
(19, 1715593244, 10011, 100025, 1, 'full_1715593244.jpg', '2024-05-13 15:11:19'),
(18, 1715591314, 10010, 100025, 1, 'full_1715591314.jpg', '2024-05-13 14:41:12'),
(21, 1716133308, 10011, 100025, 2, 'full_1716133308.jpg', '2024-05-19 21:12:09');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_purchase_orders`
--

DROP TABLE IF EXISTS `izzysales_purchase_orders`;
CREATE TABLE IF NOT EXISTS `izzysales_purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` bigint(12) DEFAULT NULL,
  `supplier_id` bigint(12) DEFAULT NULL,
  `product_id` bigint(12) DEFAULT NULL,
  `variant` int(10) DEFAULT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `rate` float DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `total_amount` float DEFAULT NULL,
  `paid_amount` float DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_purchase_orders`
--

INSERT INTO `izzysales_purchase_orders` (`id`, `purchase_id`, `supplier_id`, `product_id`, `variant`, `product_name`, `rate`, `quantity`, `unit`, `total_amount`, `paid_amount`, `date`) VALUES
(5, 400101, 10004, 10011, 1, 'Reynolds Pen', 7, 10, 'NOS', 70, 100, '2024-05-15 12:36:01'),
(3, 400100, 10004, 10010, 2, 'Hauser Pen XO', 8, 10, 'NOS', 80, 100, '2024-05-14 17:42:30');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_reminders`
--

DROP TABLE IF EXISTS `izzysales_reminders`;
CREATE TABLE IF NOT EXISTS `izzysales_reminders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(10) DEFAULT NULL,
  `reminder_id` int(10) DEFAULT NULL,
  `reminder_message` varchar(200) DEFAULT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_reminders`
--

INSERT INTO `izzysales_reminders` (`id`, `user_id`, `reminder_id`, `reminder_message`, `date`) VALUES
(6, 100025, 2, 'Send material', '2024-05-18 18:31:31');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_settings`
--

DROP TABLE IF EXISTS `izzysales_settings`;
CREATE TABLE IF NOT EXISTS `izzysales_settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(30) DEFAULT NULL,
  `address` varchar(200) DEFAULT NULL,
  `image` varchar(30) NOT NULL DEFAULT 'logo.png',
  `date` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_settings`
--

INSERT INTO `izzysales_settings` (`id`, `company_name`, `address`, `image`, `date`) VALUES
(1, 'IzzySales', '', 'logo.png', '2024-05-18 18:28:00');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_suppliers`
--

DROP TABLE IF EXISTS `izzysales_suppliers`;
CREATE TABLE IF NOT EXISTS `izzysales_suppliers` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `supplier_id` int(11) NOT NULL,
  `supplier_name` varchar(300) NOT NULL,
  `supplier_phone` bigint(16) NOT NULL,
  `supplier_address` varchar(300) NOT NULL,
  `supplier_contact` varchar(150) NOT NULL,
  `supplier_gst` varchar(100) NOT NULL,
  `supplier_credit` bigint(16) DEFAULT '0',
  `supplier_debit` bigint(16) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_suppliers`
--

INSERT INTO `izzysales_suppliers` (`id`, `supplier_id`, `supplier_name`, `supplier_phone`, `supplier_address`, `supplier_contact`, `supplier_gst`, `supplier_credit`, `supplier_debit`, `date`) VALUES
(4, 10004, 'Beeco Stationers', 999999999, 'Kursoo', 'Ghulam Nabi', 'ASDER12345', 0, 0, '2024-05-18 12:35:16'),
(5, 10005, 'Star Stationers', 999999999, 'Some', 'Malik', '', 0, 0, '2024-05-18 12:35:16');

-- --------------------------------------------------------

--
-- Table structure for table `izzysales_users`
--

DROP TABLE IF EXISTS `izzysales_users`;
CREATE TABLE IF NOT EXISTS `izzysales_users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `fname` varchar(20) NOT NULL,
  `lname` varchar(20) DEFAULT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL,
  `role` varchar(1) NOT NULL,
  `status` varchar(1) NOT NULL,
  `email` varchar(30) NOT NULL DEFAULT 'test@mail.com',
  `phone` varchar(10) NOT NULL DEFAULT '9999999999',
  `image` varchar(30) NOT NULL DEFAULT 'default.png',
  `user_id` int(10) NOT NULL,
  `passkey` varchar(30) DEFAULT NULL,
  `regtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `izzysales_users`
--

INSERT INTO `izzysales_users` (`id`, `fname`, `lname`, `username`, `password`, `role`, `status`, `email`, `phone`, `image`, `user_id`, `passkey`, `regtime`) VALUES
(4, 'John', 'Doe', 'johndoe', 'john@2024', '2', '1', 'default@mail.com', '8491860921', 'default.png', 100001, '111057', '2022-10-03 01:00:56'),
(18, 'Shoeb', 'Hamid', 'shoebhamid', 'shoeb1234', '1', '1', 'shoebhamid@mail.com', '9999999998', '1716058790.jpg', 100025, '0', '2023-12-22 02:58:27');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
