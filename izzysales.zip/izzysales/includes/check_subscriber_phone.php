<?php
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected.");
}
	if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
        die();
		}
 include_once('../config.php');
                    
 $userphone = filter_var($_POST["newphone"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
    		$sql2 = "SELECT * FROM be_users WHERE phone = '$userphone' ";
			$result2 = $mysqli->query($sql2);
			$rowcnt=$result2->num_rows;
			if ($rowcnt > 0 ) {
			echo "! ".$userphone." phone registered already, try a different one";
					
			} 
			
			//echo "all well";
			//die;
			$mysqli->close();
            
?>
 		