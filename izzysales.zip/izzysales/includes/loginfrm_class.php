<?php session_start();
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected and not available to public.");
}   
include('../config.php');	
   
   // Class to validate user inputs without db
class frm_validate {
		
		function fields_empty_check($username, $password) {
			if ($username =="" && $password =="") {
			echo "! Error: Empty fields";
			global $formerror;
			$formerror = TRUE;
			//die;
			}
		}
		
        	function field_empty_check($field, $message) {
			if ($field =="") {
			echo "! Error: ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
			}
		}	
		
		
				
		function letter_match_check($field, $message) {
			if (!preg_match("/^[a-zA-Z ]*$/",$field)) {
			echo "! ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
                   }
		}
		
		
		function letter_match_usrname($field, $message) {
			if (!preg_match('/^[a-zA-Z0-9]*$/',$field)) {
			echo "! ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
                  }
		}
		
		function letter_match_usrnm($field, $message) {
			if (!preg_match('/^[a-zA-Z0-9]{6,15}$/',$field)) {
			echo "! ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
                  }
		}
		
		function phone_match_check($field, $message) {
			if (!preg_match('/^[0-9]{10}$/', $field)) {
			echo "! ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
           }
		}
		
		
		function email_match_check($field, $message) {
			if (!preg_match("/^[^@]+@[^@]+\.[a-z]{2,6}$/i",$field)) {
			echo "! ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
           }
		}
		
		function char_length_check($field, $message) {
			if (strlen($field) < 6) {
			echo "! ".$message;
			global $formerror;
			$formerror = TRUE;
			die;
           }
		}
		
	}
	
	class Database
{
    /** TRUE if static variables have been initialized. FALSE otherwise
    */
    private static $init = FALSE;
    /** The mysqli connection object
    */
    public static $conn;
    /** initializes the static class variables. Only runs initialization once.
    * does not return anything.
    */
    
}
	
// Class to send ajax resquest 
class user_validate_ajax {	
    public $role ="";
	function chkuser() {	
		if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
        die();
		}
		   // Database::initialize();
include('../mysqli.php');
	
			$username = filter_var($_POST["username"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
		        $password = filter_var($_POST["password"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
		        $sql = "SELECT * FROM izzysales_users WHERE username = '$username' AND password = '$password'";
			$result = mysqli_query ($mysqli, $sql);
			$rowcnt=$result->num_rows;
			if ($rowcnt <1 && $username !=="" && $password !=="") {
			echo "! Invalid Username, Password";
			} else{
				$this->redirect_user();
				$mysqli->close();
				}
		}
		
	function redirect_user() {
		//Database::initialize();
include('../mysqli.php');

        $username = filter_var($_POST["username"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
        $password = filter_var($_POST["password"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
	$sql = "SELECT * FROM izzysales_users WHERE username = '$username' AND password = '$password'";
	    $result = mysqli_query ($mysqli, $sql);
		while($row = $result->fetch_assoc()) {
        $role = $row["role"];
		$status = $row["status"];
		$usrnme = $row["username"];
		$usrfnme = $row["fname"];
		$usrlnme = $row["lname"];
		$usrimg = $row["image"];
		$usrid = $row["user_id"];	
		$phone_num = $row["phone"];
		}
		if($role=="1" && $status=="1"){
	   $_SESSION["user_role"] = "admin";
	   $_SESSION["user_name"] = $usrnme;
	   $_SESSION["user_fname"] = $usrfnme;
	   $_SESSION["user_lname"] = $usrlnme;
	   $_SESSION["user_img"] = $usrimg;
	   $_SESSION["user_id"] = $usrid;
	   $_SESSION["phone"] = $phone_num;
	   $_SESSION["user_passcode"] = rand(9999999, 99999999);
	   $mysqli->close();
	   $url=ME_URI."dashboard";
	   echo '<script type="text/javascript">';
           echo 'window.location.href="'.$url.'";';
           echo '</script>';
           echo '<noscript>';
           echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
           echo '</noscript>';
	    }
	    elseif($role=="2" && $status=="1"){
	   $_SESSION["user_role"] = "auth";
	   $_SESSION["user_name"] = $usrnme;
	   $_SESSION["user_fname"] = $usrfnme;
	   $_SESSION["user_lname"] = $usrlnme;
	   $_SESSION["user_img"] = $usrimg;
	   $_SESSION["user_id"] = $usrid;
	   $_SESSION["phone"] = $phone_num;
	   $_SESSION["user_passcode"] = rand(9999999, 99999999);
	   $mysqli->close();
	   $url=ME_URI."dashboard/auth/";
	   echo '<script type="text/javascript">';
           echo 'window.location.href="'.$url.'";';
           echo '</script>';
           echo '<noscript>';
           echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
           echo '</noscript>';
	    }
	     	    
	    elseif($role=="3" && $status=="0"){
		
	   //$_SESSION["user_role"] = "user";
	   //$_SESSION["user_name"] = $usrnme;
	   //$_SESSION["user_fname"] = $usrfnme;
	  // $_SESSION["user_lname"] = $usrlnme;
	  // $_SESSION["user_img"] = $usrimg;
	  // $_SESSION["user_id"] = $usrid;
	  // $_SESSION["user_passcode"] = rand(99999999999, 999999999999);
	   $_SESSION['acc_conf']="checkyes";
	   $mysqli->close();
	   $url=ME_URI."account_confirm.php";
	   echo '<script type="text/javascript">';
           echo 'window.location.href="'.$url.'";';
           echo '</script>';
           echo '<noscript>';
           echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
           echo '</noscript>';
	    }
	    
	  elseif($role=="3" && $status=="2"){		  
	   $mysqli->close();
	        $url=ME_URI."dashboard/user/user_block.php";
	        echo '<script type="text/javascript">';
            echo 'window.location.href="'.$url.'";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
            echo '</noscript>';
	    }
	    
		else{		  
	   $mysqli->close();
	        $url=ME_URI."login.php";
	        echo '<script type="text/javascript">';
            echo 'window.location.href="'.$url.'";';
            echo '</script>';
            echo '<noscript>';
            echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
            echo '</noscript>';
	    }
	}
}

class register_user {
	
	function newuser() {	
	
	//Database::initialize();	
	include('../mysqli.php');	
   //$fname = filter_var($_POST["firstname"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   //$lname = filter_var($_POST["lastname"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $username = filter_var($_POST["newuser"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $password = filter_var($_POST["newpassword"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $newphone = filter_var($_POST["newphone"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $passkey = mt_rand(100000, 999999);
                        
           
		   
                            
  			
		        $sql = "SELECT * FROM izzysales_users WHERE username = '$username' or phone ='$newphone'" ;
			$result = mysqli_query ($mysqli, $sql);
			$rowcnt=$result->num_rows;
			if ($rowcnt < 1 ) {
				
				$sql = "SELECT * FROM  izzysales_users ORDER BY  izzysales_users.id DESC LIMIT 1";
				$result = mysqli_query ($mysqli, $sql);
				while($row = $result->fetch_assoc()) {
					$userid = $row["user_id"];
					$userid++;
					//echo $userid;
					}
				
				
			  	$sql2 = "INSERT INTO izzysales_users(fname, lname, username, password, role, status, phone, image, user_id, passkey, regtime) VALUES ('".$username."', '', '".$username."','".$password."','3','0','".$newphone."', 'default.png','".$userid."', '".$passkey."' , CURRENT_TIMESTAMP)";
				
				$result2 = mysqli_query ($mysqli, $sql2);
				
				if (isset($_SESSION['ipadd'])){
				$ipadd = $_SESSION['ipadd'];
				} else {
				$ipadd = "0.0.0.0";
				}
				
				$sql3 = "INSERT INTO pix_ip(id, user_id, ip_address, status, passkey, submit_time) VALUES ('', '".$userid."','".$ipadd."', '0', '".$passkey."', CURRENT_TIMESTAMP)";
				$result3 = mysqli_query ($mysqli, $sql3);
				
				if ($result2) {
				
				            /* $to = $newemail ;
				            $subject = "Your Confirmation Code";
				            $message = "Please use this Code to complete your Registration:" .$passkey ;
				            $headers = "From : support@kashmirpix.com";
				           
				          if(mail($to, $subject, $message, $headers)){*/
				          echo "<p>Thanks for registering. Your account will be activated in a moment. You will receive confirmation on your registered number.</p>";
				          }else{
				                 echo "Failed to Recover your password, try again";
					 $mysqli->close();
					 $url="http://localhost/";
				    	   echo '<script type="text/javascript">';
				           echo 'setTimeout(function () {window.location.href="'.$url.'"}, 6000)';
				           echo '</script>';
				           echo '<noscript>';
				           echo '<meta http-equiv="refresh" content="6;url='.$url.'" />';
				           echo '</noscript>';
				}
			
			
			} 
   
   
   
   
   
    
	
		}
	
}

