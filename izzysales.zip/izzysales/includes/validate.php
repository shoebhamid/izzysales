<?php
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected and not available to public.");
}
$usernm = (!$_POST["username"]) ? false : true;
$passwd = (!$_POST["password"]) ? false : true;
$usnm = $_POST["username"];
$pwsd = $_POST["password"];
 
include_once('loginfrm_class.php');
 $result = new frm_validate();
 $result->fields_empty_check($usnm, $pwsd);
 $result->field_empty_check($usnm,'Username cannot be empty');
 $result->letter_match_usrnm($usnm,'Enter Valid Username');
 $result->field_empty_check($pwsd,'Password cannot be empty');	

   
if($usernm && $passwd){
  $result = new user_validate_ajax();
  $result-> chkuser();
 } 
 
 ?>