<?php
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected and not available to public.");
}
	if(!isset($_SERVER['HTTP_X_REQUESTED_WITH']) AND strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') {
        die();
		}
 include_once('../config.php');
                        
 $username = filter_var($_POST["newuser"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
 
 //echo $username ;
			//die;
		        $sql = "SELECT * FROM be_users WHERE username = '$username' ";
			$result = $mysqli->query($sql);
			$rowcnt=$result->num_rows;
			if ($rowcnt > 0 ) {
			echo "! ".$username." already taken, try a different one";
			die;		
			} 
                       
    
            
?>
 		