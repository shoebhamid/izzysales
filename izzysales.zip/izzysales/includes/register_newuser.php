<?php
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected.");
}	
	//Database::initialize();	
  $fname = filter_var($_POST["firstname"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $lname = filter_var($_POST["lastname"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $username = filter_var($_POST["newusername"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $password = filter_var($_POST["newpassword"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $newemail = filter_var($_POST["newphone"], FILTER_SANITIZE_STRING, FILTER_FLAG_STRIP_LOW|FILTER_FLAG_STRIP_HIGH);
   $passkey = mt_rand(100000, 999999);
                        
                                              
                            
  			
		        $sql = "SELECT * FROM be_users WHERE username = '$username' or phone ='$newemail'   " ;
			$result = mysqli_query ($mysqli, $sql);
			$rowcnt=$result->num_rows;
			if ($rowcnt < 1 ) {
				
				$sql = "SELECT * FROM  be_users ORDER BY  be_users.id DESC LIMIT 1";
				$result = mysqli_query ($mysqli, $sql);
				while($row = $result->fetch_assoc()) {
					$userid = $row["user_id"];
					$userid++;
					}
				
				
			  	$sql2 = "INSERT INTO be_users(fname, lname, username, password, role, status, email, phone, image, user_id, passkey, regtime) VALUES ('".$userame."','','".$username."','".$password."','3','0', 'default@mail.com', '".$newemail."', 'default.png', '".$userid."', '".$passkey."' , CURRENT_TIMESTAMP)";
				$result2 = mysqli_query ($mysqli, $sql2);
				
				if (isset($_SESSION['ipadd'])){
				$ipadd = $_SESSION['ipadd'];
				} else {
				$ipadd = "0.0.0.0";
				}
				
				$sql3 = "INSERT INTO pix_ip(id, user_id, ip_address, status, passkey, submit_time) VALUES ('', '".$userid."','".$ipadd."', '0', '".$passkey."', CURRENT_TIMESTAMP)";
				$result3 = mysqli_query ($mysqli, $sql3);
				
				if ($result2) {
				
				         //   $to = $newemail ;
				         //   $subject = "Your Confirmation Code";
				         //   $message = "Please use this Code to complete your Registration:" .$passkey ;
				          //  $headers = "From : info@uckhospital.com";
				           
				          //if(mail($to, $subject, $message, $headers)){
				          echo "<p>Your Request has been sent and you will receive a six digit activation code on registered phone number. You will be redirected to Login Page shortly.</p>";
				          }else{
				                 echo "Failed to Recover your password, try again";
				          }
					 $mysqli->close();
					 $url=ME_URI."login.php";
				    	   echo '<script type="text/javascript">';
				           echo 'setTimeout(function () {window.location.href="'.$url.'"}, 6000)';
				           echo '</script>';
				           echo '<noscript>';
				           echo '<meta http-equiv="refresh" content="6;url='.$url.'" />';
				           echo '</noscript>';
				}
			
			
		 
   
   ?>
   
   
   
    
	
		