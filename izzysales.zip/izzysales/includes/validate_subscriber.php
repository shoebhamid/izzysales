<?php
if ( $_SERVER['REQUEST_METHOD']=='GET' && realpath(__FILE__) == realpath( $_SERVER['SCRIPT_FILENAME'] ) ) {
header( 'HTTP/1.0 403 Forbidden', TRUE, 403 );
die ("<h2>Access Denied!</h2> This file is protected.");
}
$newusernm = (!$_POST["newuser"]) ? false : true;
$newpasswd = (!$_POST["newpassword"]) ? false : true;
//$newfirstnm = (!$_POST["firstname"]) ? false : true;
//$newlastnm = (!$_POST["lastname"]) ? false : true;
$newphone = (!$_POST["newphone"]) ? false : true;

$newusnm = $_POST["newuser"];
$newpwsd = $_POST["newpassword"];
//$newfsnm = $_POST["firstname"];
//$newlsnm = $_POST["lastname"];
$newphone = $_POST["newphone"];

 include_once('loginfrm_class.php');
 $result = new frm_validate();
 //$result->field_empty_check($newfsnm, "First Name cannot be empty");
 //$result->letter_match_check($newfsnm, 'First Name - use only letters A-Z');
 //$result->field_empty_check($newlsnm, 'Last Name cannot be empty');
 //$result->letter_match_check($newlsnm, 'Last Name - use only letters A-Z');
 $result->field_empty_check($newusnm, 'Username cannot be empty');
 $result->letter_match_usrname($newusnm, 'Use only alphabets, numbers and minimum 6 characters in username');
 $result->char_length_check($newusnm, 'Username must be atleast 6 characters');
  $result->field_empty_check($newpwsd, 'Password cannot be empty');
 $result->char_length_check($newpwsd, 'Password must be atleast 6 characters'); 
 $result->field_empty_check($newphone, 'Phone cannot be empty');
 $result->phone_match_check($newphone, 'Phone is invalid');

 $register = new register_user();
 $register->newuser();
 
 
  