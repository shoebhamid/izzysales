<?php session_start();
$_SESSION['ipadd'] = $_SERVER['REMOTE_ADDR'];
?>
<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="js/jquery.min.js"></script>
  <script src="js/min.js"></script>
  <title>Izzy Sales Login Form</title>
  <link rel="stylesheet" href="css/stylelogin.css">
</head>

<body style="background: url(img/pix-bg-login.png);">
<div id="registration-form" action="post">
  	  
  <div class="login-wrap">
	<div class="login-html">
		<input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Sign In</label>
		<input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab"></label>
		<div class="login-form">
			<div class="sign-in-htm">
				<form id="loginfrm">
				    <div class="group">
					
					<input name="username" id="username" type="text" class="input" placeholder="Username">
					</div>
					
					<div class="group">
				
					<input id="password" type="password" name ="password" class="input" data-type="password" placeholder="Password">
					</div>
					
					<div class="group">
					<input id="check" type="checkbox" class="check" checked>
					<label for="check"><span class="icon"></span> Keep me Signed in</label>
					</div>
					
					
												
					<div class="group">
					<input type="button" id ="submit-login" class="button" value="Sign In">
					</div>
					<div class="hr"></div>
					<p id="user-result" style="color:#d7e033; font-weight:200; font-size:18px; text-align:center"></p>
					<div class="foot-lnk">
					<a href="https://billionengineers.co.in" style="color: #fff;">IzzySales: BETA</a>
					
					</div>
				</form>
			</div>
			
		</div>
	</div>
</div>
</div>
  
  
</body>
</html>
