<?php
define('useraccess', TRUE);
?>