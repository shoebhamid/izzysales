<?php 
if (!isset($_SESSION["user_name"])) {
	 header("location:login.php");
	 die;
 } 
include('config.php');
include('mysqli.php');


$sql="SELECT image FROM izzysales_settings";
$result = mysqli_query($mysqli, $sql);
     while($row = mysqli_fetch_assoc($result)) {
        $image= $row["image"];
	}
if($image == "default.png"){
$img_name = 'dashboard/content/site_images/logo.png';	
} else {
	$img_name = 'dashboard/content/site_images/'.$image;
}

?>  

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	
	<div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <div class="nav-header">
            <a href="<?php echo ME_URI;?>dashboard/" class="brand-logo">
                <img class="logo-abbr" src="<?php echo ME_URI.$img_name;?>" alt="">
               <span style="font-size: 14px;font-weight: 300; padding-left:5px"><?php echo $company_name;?></span>
            </a>

            
        </div>

        <div class="header">
            <div class="header-content">
                <nav class="navbar navbar-expand">
                    <div class="collapse navbar-collapse justify-content-between">
                        <div class="header-left">
                            <div class="search_bar dropdown">
                                <span class="search_icon p-3 c-pointer" data-toggle="dropdown">
                                    <i class="mdi mdi-magnify"></i>
                                </span>
                                <div class="dropdown-menu p-0 m-0">
                                    <form>
                                        <input class="form-control" type="search" placeholder="Search" aria-label="Search">
                                    </form>
                                </div>
                            </div>
                        </div>

                        <ul class="navbar-nav header-right">
                            <li class="nav-item dropdown notification_dropdown">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <i class="mdi mdi-bell"></i>
                                    <div class="pulse-css"></div>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <ul class="list-unstyled">
                                        <li class="media dropdown-item">
                                            FREE BETA VERSION
                                        </li>   
                                    </ul>
                                    <a class="all-notification" href="">See all reminders <i
                                            class="ti-arrow-right"></i></a>
                                </div>
                            </li>
                            <li class="nav-item dropdown header-profile">
                                <a class="nav-link" href="#" role="button" data-toggle="dropdown">
                                    <img src="<?php echo ME_URI;?>dashboard/user/user_pic/<?php echo $usr_dp_pic;?>"></a>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a href="<?php echo ME_URI;?>dashboard/admin/profile.php" class="dropdown-item">
                                        <i class="icon-user"></i>
                                       <span class="ml-2">Profile</span></a>
                                    </a>
                                  
                                    <a href="<?php echo ME_URI;?>logout.php" class="dropdown-item">
                                        <i class="icon-key"></i>
                                        <span class="ml-2">Logout </span>
                                    </a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->